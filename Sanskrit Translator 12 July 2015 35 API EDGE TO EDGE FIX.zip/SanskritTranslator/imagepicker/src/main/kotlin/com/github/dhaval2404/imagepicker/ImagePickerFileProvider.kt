package com.github.dhaval2404.imagepicker

import androidx.core.content.FileProvider

class ImagePickerFileProvider : FileProvider()

package shubhamjit.san.hindi.sanskrit_hindi;

import android.app.Activity;
import android.app.ActivityOptions;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Random;

import shubhamjit.san.hindi.R;

public class Util {

	public static String sfName = "sfName";
	public static String KEY_adWatchedOn = "KEY_adWatchedOn";
	public static String KEY_tempText = "KEY_tempText";

		public static boolean isConnected(Context a) {
				ConnectivityManager connectivityManager = (ConnectivityManager)
						a.getSystemService(Activity.CONNECTIVITY_SERVICE);
				NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
				return activeNetworkInfo != null && activeNetworkInfo.isConnected();
		}

	public static Bitmap toBitmap(Context context, Uri uri) {
		try {
			InputStream inputStream = context.getContentResolver().openInputStream(uri);
			return BitmapFactory.decodeStream(inputStream);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}



		public static int getRandomNo(int _min, int _max) {
				Random random = new Random();
				return random.nextInt(_max - _min + 1) + _min;
		}

	public static String High_ImgQuality() {

		return "q=100&w=1000";
	}

	public static String Low_ImgQuality() {

		return "q=80&w=400";
	}


	public static void showAnimationName (final View view, final String AnimationName) {
		view.setTransitionName(AnimationName);
	}

	public static void setActivityAnimation (final View view, final String AnimationName, Activity ctx, final Intent _intent) {
		view.setTransitionName(AnimationName);
		ActivityOptions optionsCompat = ActivityOptions.makeSceneTransitionAnimation(ctx,
				view, AnimationName);
		ctx.startActivity(_intent, optionsCompat.toBundle());
	}


	public static void showAlert(String msg, boolean is_cancel, String title, Activity ctx)
	{
		try {
			new AlertDialog.Builder(ctx)
					.setMessage(msg.trim())
					.setCancelable(is_cancel)
					.setTitle(title.trim())
					.setPositiveButton("OK", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialogInterface, int i) {
							ctx.finish();
						}
					}).create().show();
		}catch (Exception e) {


		}

	}


	public static String copyFromInputStream(InputStream inputStream) {
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		byte buf[] = new byte[1024];
		int i;
		try {
			while ((i = inputStream.read(buf)) != -1){
				outputStream.write(buf, 0, i);
			}
			outputStream.close();
			inputStream.close();
		} catch (IOException e) {

		}
		return outputStream.toString();
	}

	public static void showToast(String _msg, Context ctx) {
			Toast.makeText(ctx, _msg, Toast.LENGTH_LONG).show();

	}

	public static void log(String _msg, Context ctx) {
			Log.d("log2024",_msg +" >>> "+ctx.toString());
		}

	public static void show_no_connection(Activity ctx) {

		if (Util.isConnected(ctx)) {

			Util.showAlert("Retry task again.",
					false, "Internet slow! Try again", ctx);


		} else {

			Util.showAlert("Check your WIFI or Mobile Internet connection..",
					false, "No internet!", ctx);

		}
	}






	public static void share_text(Context CTX, String text) {
		//Uri uri = get_path_image_for_Share(bitmap);

		try {
			Intent intent = new Intent(Intent.ACTION_SEND);


			//intent.putExtra(Intent.EXTRA_STREAM, uri);
			intent.putExtra(Intent.EXTRA_TEXT, text.trim());
			intent.putExtra(Intent.EXTRA_SUBJECT, CTX.getResources().getString(R.string.app_name));
			intent.setType("text/plain");
			//intent.setType("image/png");
			CTX.startActivity(Intent.createChooser(intent, "Share on"));
		}catch (Exception e)
		{
			e.printStackTrace();
			Util.showToast("Failed to share..",CTX);
		}

	}

}
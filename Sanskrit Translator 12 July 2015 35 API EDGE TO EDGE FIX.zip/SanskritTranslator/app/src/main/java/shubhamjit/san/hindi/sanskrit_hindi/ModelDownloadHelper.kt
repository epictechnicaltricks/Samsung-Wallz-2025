package shubhamjit.san.hindi.sanskrit_hindi

import android.content.Context
import com.google.android.gms.common.moduleinstall.ModuleInstall
import com.google.android.gms.common.moduleinstall.ModuleInstallRequest
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions


object ModelDownloadHelper {

    fun checkAndDownloadModel(context: Context) {
        val moduleInstallClient = ModuleInstall.getClient(context)
        val optionalModuleApi = TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
        moduleInstallClient
            .areModulesAvailable(optionalModuleApi)
            .addOnSuccessListener { response ->
                if (!response.areModulesAvailable()) {
                    println("Model not available. Requesting download...")

                    //moduleInstallClient.deferredInstall(optionalModuleApi)

                    val moduleInstallRequest = ModuleInstallRequest.newBuilder()
                            .addApi(optionalModuleApi)
                            // Add more APIs if you would like to request multiple optional modules.
                            // .addApi(...)
                            // Set the listener if you need to monitor the download progress.
                            // .setListener(listener)
                            .build()

                    moduleInstallClient
                        .installModules(moduleInstallRequest)
                        .addOnSuccessListener {
                            if (it.areModulesAlreadyInstalled()) {
                                println(" Modules are already installed when the request is sent....")

                                // Modules are already installed when the request is sent.
                            }
                        }
                        .addOnFailureListener {
                            println("error 464 ${it}")

                            // Handle failure…
                        }


                } else {
                    println("Model is already available.")
                }
            }
            .addOnFailureListener {
                // Handle failure...
            }
    }
}

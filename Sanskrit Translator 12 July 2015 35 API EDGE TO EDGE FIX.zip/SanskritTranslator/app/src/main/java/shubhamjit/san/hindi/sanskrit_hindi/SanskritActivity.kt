package shubhamjit.san.hindi.sanskrit_hindi

import android.animation.ObjectAnimator
import android.app.ProgressDialog
import android.content.*
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Insets
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import android.text.Editable
import android.text.TextWatcher
import android.transition.AutoTransition
import android.transition.TransitionManager
import android.util.Log
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.*
import android.widget.AdapterView.OnItemClickListener
import android.widget.AdapterView.OnItemLongClickListener
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.github.dhaval2404.imagepicker.ImagePicker
import com.google.android.ads.nativetemplates.NativeTemplateStyle
import com.google.android.ads.nativetemplates.TemplateView
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewarded.RewardItem
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.appupdate.AppUpdateOptions
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.UpdateAvailability
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import org.json.JSONArray
import shubhamjit.san.hindi.BuildConfig
import shubhamjit.san.hindi.R
import shubhamjit.san.hindi.sanskrit_hindi.RequestNetwork.RequestListener
import java.net.URLEncoder
import java.util.*

class SanskritActivity : AppCompatActivity() {
    private val _timer = Timer()
    private var text = ""
    private var params = HashMap<String, Any>()
    private var map = HashMap<String, Any>()
    private var bookmark_visible = false
    private var to_lang = ""
    private var to_lang_code: String? = ""
    private var from_lang_code: String? = ""
    private var from_lang = ""
    private var len = 0.0
    private var listmap_bookmarks = ArrayList<HashMap<String, Any>>()
    private val gs = ArrayList<String>()
    private var nav: LinearLayout? = null
    private var topbar: LinearLayout? = null
    private var layout: LinearLayout? = null
    private var btn_bookmarks: ImageView? = null
    private var tv_title: TextView? = null
    private var btn_give_like: ImageView? = null
    private var vscroll: ScrollView? = null
    private var cardview_bookmark: CardView? = null
    private var linear_scroll: LinearLayout? = null
    private var cardview: CardView? = null
    private var linear_card: LinearLayout? = null
    private var linear: LinearLayout? = null
    private var linear_translated: LinearLayout? = null
    private var linear5: LinearLayout? = null
    private var linear9: LinearLayout? = null
    private var et_text_translate: EditText? = null
    private var linear11: LinearLayout? = null
    private var tv_from_lang: TextView? = null
    private var btn_change_lamguage: ImageView? = null
    private var tv_to_lang: TextView? = null
    private var btn_paste: ImageView? = null
    private var btn_clear: ImageView? = null
    private var tv_translated_text: TextView? = null
    private var linear10: LinearLayout? = null
    private var speaker: ImageView? = null
    private var btn_copy: ImageView? = null
    private var btn_bookmark: ImageView? = null
    private var linear_bookmarks: LinearLayout? = null
    private var linear12: LinearLayout? = null
    private var gridview: GridView? = null
    private var textview5: TextView? = null
    private var imageview1: ImageView? = null
    private var api: RequestNetwork? = null
    private var _api_request_listener: RequestListener? = null
    private var translate_timer: TimerTask? = null
    private var data: SharedPreferences? = null

    private val oa = ObjectAnimator()
    private val tg = Intent()
    private var adsRemoveLayout: LinearLayout? = null
    private var sharedPreferences: SharedPreferences? = null
    private var sfEditor: SharedPreferences.Editor? = null
    var progressDialog: ProgressDialog? = null
    private var mRewardedAd: RewardedAd? = null
    var template: TemplateView? = null

    // Creates instance of the manager.

    private var recognizer: TextRecognizer? = null




    private val appUpdateManager by lazy { AppUpdateManagerFactory.create(this) }

    lateinit var dialog : AlertDialog




    override fun onCreate(_savedInstanceState: Bundle?) {
        super.onCreate(_savedInstanceState)
        setContentView(R.layout.san_main)

        if (Build.VERSION.SDK_INT >= 35) {
            // Enables edge-to-edge layout
            WindowCompat.setDecorFitsSystemWindows(window, false)

            val mainView = findViewById<View>(R.id.main)

            val extraTopPadding = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                35f,
                mainView.resources.displayMetrics
            ).toInt()

            ViewCompat.setOnApplyWindowInsetsListener(mainView) { v, insets ->
                val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
                v.setPadding(
                    systemBars.left,
                    systemBars.top + extraTopPadding,
                    systemBars.right,
                    systemBars.bottom
                )
                insets
            }
        }



        initialize()



        tv_title = findViewById<View>(R.id.tv_title) as TextView
        //NATIVE ADS ADMOB
        template = findViewById(R.id.my_template)
        template!!.setVisibility(View.GONE)
        adsRemoveLayout!!.visibility = View.GONE
        if (sharedPreferences!!.getLong(Util.KEY_adWatchedOn, 0) == 0L) {
            Log.d("watchAd", "1111 KEY_adWatchedOn 0")
            val adLoader = AdLoader.Builder(this, resources.getString(R.string.native_id))
                .forNativeAd { nativeAd ->
                    val colorDrawable =
                        ColorDrawable(Color.parseColor("#0033ad94")) // transparent color -> remove 00 first
                    val styles =
                        NativeTemplateStyle.Builder().withMainBackgroundColor(colorDrawable).build()
                    _TransitionManager(nav, 1000.0)
                    template!!.setStyles(styles)
                    template!!.setNativeAd(nativeAd)
                    template!!.setVisibility(View.VISIBLE)
                    adsRemoveLayout!!.visibility = View.VISIBLE
                }
                .build()
            adLoader.loadAd(AdRequest.Builder().build())
        } else {
            Log.d(
                "watchAd",
                "222 KEY_adWatchedOn " + sharedPreferences!!.getLong(Util.KEY_adWatchedOn, 0)
            )
            if (TimeCheck.is48HoursCompleted(
                    sharedPreferences!!.getLong(
                        Util.KEY_adWatchedOn,
                        0
                    )
                )
            ) {
                //reset the 48hr time
                sfEditor!!.putLong(Util.KEY_adWatchedOn, 0)
                sfEditor!!.apply()
                Util.showToast("48hr Ads Free gone!", this@SanskritActivity)
                Log.d(
                    "watchAd",
                    "3333 is48HoursCompleted TRUE " + sharedPreferences!!.getLong(
                        Util.KEY_adWatchedOn,
                        0
                    )
                )
                val adLoader = AdLoader.Builder(this, resources.getString(R.string.native_id))
                    .forNativeAd { nativeAd ->
                        val colorDrawable =
                            ColorDrawable(Color.parseColor("#0033ad94")) // transparent color -> remove 00 first
                        val styles =
                            NativeTemplateStyle.Builder().withMainBackgroundColor(colorDrawable)
                                .build()
                        _TransitionManager(nav, 1000.0)
                        template!!.setStyles(styles)
                        template!!.setNativeAd(nativeAd)
                        template!!.setVisibility(View.VISIBLE)
                        adsRemoveLayout!!.visibility = View.VISIBLE
                    }
                    .build()
                adLoader.loadAd(AdRequest.Builder().build())
            } else {
                Log.d(
                    "watchAd", "4444 is48HoursCompleted FALSE %PRO% " + sharedPreferences!!.getLong(
                        Util.KEY_adWatchedOn, 0
                    )
                )
                tv_title!!.setTextColor(resources.getColor(R.color.colorAccent))
                tv_title!!.text = "Sanskrit Translator Pro"
            }
        }
        initializeLogic()
        checkUpdate()
    }

    override fun onResume() {
        et_text_translate!!.setText(sharedPreferences!!.getString(Util.KEY_tempText, ""))

           // Resume interrupted updates if applicable
        appUpdateManager.appUpdateInfo.addOnSuccessListener { appUpdateInfo ->
            if (appUpdateInfo.updateAvailability() == UpdateAvailability.DEVELOPER_TRIGGERED_UPDATE_IN_PROGRESS) {
                appUpdateManager.startUpdateFlow(
                    appUpdateInfo,
                    this,
                    AppUpdateOptions.newBuilder(AppUpdateType.IMMEDIATE).build()
                )
            }
        }


        super.onResume()
    }



    private fun initialize() {
        //recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);

        ModelDownloadHelper.checkAndDownloadModel(this@SanskritActivity)

        recognizer = TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())

        dialog = Utils.showMaterialProgressBarDialog(this@SanskritActivity)



        sharedPreferences = getSharedPreferences(Util.sfName, MODE_PRIVATE)
        sfEditor = sharedPreferences!!.edit()
        progressDialog = ProgressDialog(this)
        progressDialog!!.setMessage("Loading video ad...")
        progressDialog!!.setCancelable(false)
        adsRemoveLayout = findViewById(R.id.removeAdsLayout)
        nav = findViewById<View>(R.id.nav) as LinearLayout
        topbar = findViewById<View>(R.id.topbar) as LinearLayout
        layout = findViewById<View>(R.id.layout) as LinearLayout
        btn_bookmarks = findViewById<View>(R.id.btn_bookmarks) as ImageView
        btn_give_like = findViewById<View>(R.id.btn_give_like) as ImageView
        vscroll = findViewById<View>(R.id.vscroll) as ScrollView
        cardview_bookmark = findViewById<View>(R.id.cardview_bookmark) as CardView
        linear_scroll = findViewById<View>(R.id.linear_scroll) as LinearLayout
        cardview = findViewById<View>(R.id.cardview) as CardView
        linear_card = findViewById<View>(R.id.linear_card) as LinearLayout
        linear = findViewById<View>(R.id.linear) as LinearLayout
        linear_translated = findViewById<View>(R.id.linear_translated) as LinearLayout
        linear5 = findViewById<View>(R.id.linear5) as LinearLayout
        linear9 = findViewById<View>(R.id.linear9) as LinearLayout
        et_text_translate = findViewById<View>(R.id.et_text_translate) as EditText
        linear11 = findViewById<View>(R.id.linear11) as LinearLayout
        tv_from_lang = findViewById<View>(R.id.tv_from_lang) as TextView
        btn_change_lamguage = findViewById<View>(R.id.btn_change_lamguage) as ImageView
        tv_to_lang = findViewById<View>(R.id.tv_to_lang) as TextView
        btn_paste = findViewById<View>(R.id.btn_paste) as ImageView
        btn_clear = findViewById<View>(R.id.btn_clear) as ImageView
        tv_translated_text = findViewById<View>(R.id.tv_translated_text) as TextView
        linear10 = findViewById<View>(R.id.linear10) as LinearLayout
        speaker = findViewById<View>(R.id.speaker) as ImageView
        btn_copy = findViewById<View>(R.id.btn_copy) as ImageView
        btn_bookmark = findViewById<View>(R.id.btn_bookmark) as ImageView
        linear_bookmarks = findViewById<View>(R.id.linear_bookmarks) as LinearLayout
        linear12 = findViewById<View>(R.id.linear12) as LinearLayout
        gridview = findViewById<View>(R.id.gridview) as GridView
        textview5 = findViewById<View>(R.id.textview5) as TextView
        imageview1 = findViewById<View>(R.id.imageview1) as ImageView
        api = RequestNetwork(this)
        data = getSharedPreferences("data", MODE_PRIVATE)
        btn_bookmarks!!.setOnClickListener {
            if (bookmark_visible) {
                _TransitionManager(nav, 200.0)
                bookmark_visible = false
                cardview_bookmark!!.visibility = View.GONE
            } else {
                _TransitionManager(nav, 200.0)
                bookmark_visible = true
                cardview_bookmark!!.visibility = View.VISIBLE
                _hideKeyboard()
            }
        }
        btn_give_like!!.setOnClickListener {
            tg.action = Intent.ACTION_VIEW
            tg.data = Uri.parse("https://play.google.com/store/apps/details?id=$packageName")
            startActivity(tg)
        }
        findViewById<View>(R.id.privacy).setOnClickListener {
            val ii = Intent()
            ii.action = Intent.ACTION_VIEW
            ii.data = Uri.parse("https://sites.google.com/view/sanskrittranslator/")
            startActivity(ii)
        }
        et_text_translate!!.setOnClickListener {
            if (bookmark_visible) {
                _TransitionManager(nav, 200.0)
                bookmark_visible = false
                cardview_bookmark!!.visibility = View.GONE
            }
        }
        et_text_translate!!.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(
                _param1: CharSequence,
                _param2: Int,
                _param3: Int,
                _param4: Int
            ) {
                val _charSeq = _param1.toString()
                if (_charSeq.trim { it <= ' ' } != "") {
                    sfEditor!!.putString(Util.KEY_tempText, _charSeq)
                    sfEditor!!.apply()
                }
                try {
                    translate_timer!!.cancel()
                } catch (e: Exception) {
                }
                translate_timer = object : TimerTask() {
                    override fun run() {
                        runOnUiThread {
                            if (et_text_translate!!.text.toString().trim { it <= ' ' } == "") {
                                _TransitionManager(nav, 200.0)
                                linear_translated!!.visibility = View.GONE
                            } else {
                                _TransitionManager(nav, 200.0)
                                bookmark_visible = false
                                cardview_bookmark!!.visibility = View.GONE
                                text = et_text_translate!!.text.toString().trim { it <= ' ' }
                                params = HashMap()
                                params["User-Agent"] = "Mozilla/5.0"
                                api!!.setParams(params, RequestNetworkController.REQUEST_PARAM)
                                try {
                                    val url =
                                        "https://translate.googleapis.com/translate_a/single?client=gtx&sl=" + data!!.getString(
                                            "lang_from_code",
                                            ""
                                        ) + "&tl=" + data!!.getString(
                                            "lang_to_code",
                                            ""
                                        ) + "&dt=t&q=" + URLEncoder.encode(text, "UTF-8")
                                    api!!.startRequestNetwork(
                                        RequestNetworkController.GET,
                                        url,
                                        "a",
                                        _api_request_listener
                                    )
                                    if(BuildConfig.DEBUG)
                                    {
                                        Log.d("ddd2133", Gson().toJson(params))
                                        Log.d("ddd2133", url)
                                    }

                                } catch (e: Exception) {
                                    e.printStackTrace()
                                 //   _snackbar("An error occurred")
                                }
                            }
                        }
                    }
                }
                _timer.schedule(translate_timer, 1000)
            }

            override fun beforeTextChanged(
                _param1: CharSequence,
                _param2: Int,
                _param3: Int,
                _param4: Int
            ) {
            }

            override fun afterTextChanged(_param1: Editable) {}
        })
        tv_from_lang!!.setOnClickListener {
            intent.putExtra("type", "from")
            intent.setClass(applicationContext, LanguageActivity::class.java)
            startActivity(intent)
        }
        btn_change_lamguage!!.setOnClickListener {
            oa.target = linear5
            oa.setPropertyName("alpha")
            oa.setFloatValues(0.toFloat(), 1.toFloat())
            oa.start()
            to_lang = tv_to_lang!!.text.toString()
            to_lang_code = data!!.getString("lang_to_code", "")
            from_lang_code = data!!.getString("lang_from_code", "")
            from_lang = tv_from_lang!!.text.toString()
            data!!.edit().putString("lang_to", from_lang).commit()
            data!!.edit().putString("lang_to_code", from_lang_code).commit()
            data!!.edit().putString("lang_from", to_lang).commit()
            data!!.edit().putString("lang_from_code", to_lang_code).commit()
            tv_from_lang!!.text = data!!.getString("lang_from", "")
            tv_to_lang!!.text = data!!.getString("lang_to", "")
            _TransitionManager(nav, 200.0)
            bookmark_visible = false
            cardview_bookmark!!.visibility = View.GONE
            if (et_text_translate!!.text.toString().trim { it <= ' ' } == "") {
            } else {
                text = et_text_translate!!.text.toString().trim { it <= ' ' }
                params = HashMap()
                params["User-Agent"] = "Mozilla/5.0"
                api!!.setParams(params, RequestNetworkController.REQUEST_PARAM)
                try {
                    api!!.startRequestNetwork(
                        RequestNetworkController.GET,
                        "https://translate.googleapis.com/translate_a/single?client=gtx&sl=" + data!!.getString(
                            "lang_from_code",
                            ""
                        ) + "&tl=" + data!!.getString(
                            "lang_to_code",
                            ""
                        ) + "&dt=t&q=" + URLEncoder.encode(text, "UTF-8"),
                        "a",
                        _api_request_listener
                    )
                } catch (e: Exception) {
                    e.printStackTrace()
                   // _snackbar("An error occurred")
                }
            }
        }
        tv_to_lang!!.setOnClickListener {
            intent.putExtra("type", "to")
            intent.setClass(applicationContext, LanguageActivity::class.java)
            startActivity(intent)
        }
        btn_paste!!.setOnClickListener {
            val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            try {
                et_text_translate!!.setText(clipboard.text.toString().trim { it <= ' ' })
            } catch (e: Exception) {
                Util.showToast("Not copied any text", applicationContext)
            }
        }
        btn_clear!!.setOnClickListener { et_text_translate!!.setText("") }
        speaker!!.setOnClickListener {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            intent.putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, resources.getString(R.string.voice_speech_lang))
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT,  resources.getString(R.string.voice_speech_text_msg))

            try {
                startActivityForResult(intent, REQ_CODE_SPEECH_INPUT)
            } catch (a: ActivityNotFoundException) {
             a.printStackTrace()
            //  Toast.makeText(applicationContext, "There was an error", Toast.LENGTH_SHORT).show()
            }
        }
        btn_copy!!.setOnClickListener {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(
                ClipData.newPlainText(
                    "clipboard",
                    tv_translated_text!!.text.toString()
                )
            )
            _snackbar("Copied to clipboard")
        }
        btn_bookmark!!.setOnClickListener {
            map = HashMap()
            map["text"] = et_text_translate!!.text.toString()
            map["translate"] = tv_translated_text!!.text.toString()
            listmap_bookmarks.add(map)
            gridview!!.adapter = GridviewAdapter(listmap_bookmarks)
            _snackbar("Added to bookmarks")
            _save_bookmark_list()
        }
        gridview!!.onItemClickListener = OnItemClickListener { _param1, _param2, _param3, _param4 ->
            et_text_translate!!.setText(listmap_bookmarks[_param3]["text"].toString())
            _setCursorPosition(
                et_text_translate,
                et_text_translate!!.text.toString().length.toDouble()
            )
        }
        gridview!!.onItemLongClickListener =
            OnItemLongClickListener { _param1, _param2, _param3, _param4 ->
                _TransitionManager(nav, 200.0)
                listmap_bookmarks.removeAt(_param3)
                gridview!!.adapter = GridviewAdapter(listmap_bookmarks)
                if (listmap_bookmarks.size == -1) {
                    bookmark_visible = false
                    cardview_bookmark!!.visibility = View.GONE
                }
                _save_bookmark_list()
                _snackbar("Removed from bookmarks")
                true
            }
        imageview1!!.setOnClickListener {
            if (bookmark_visible) {
                _TransitionManager(nav, 200.0)
                bookmark_visible = false
                cardview_bookmark!!.visibility = View.GONE
            } else {
                _TransitionManager(nav, 200.0)
                bookmark_visible = true
                cardview_bookmark!!.visibility = View.VISIBLE
                _hideKeyboard()
            }
        }
        _api_request_listener = object : RequestListener {
            override fun onResponse(
                _param1: String,
                _param2: String,
                _param3: HashMap<String, Any>
            ) {
                val _tag = _param1
                val _responseHeaders = _param3
                tv_translated_text!!.text = ""
                try {
                    _TransitionManager(nav, 200.0)
                    linear_translated!!.visibility = View.VISIBLE
                    val JsonArray1 = JSONArray(_param2)
                    val JsonArray2 = JsonArray1.getJSONArray(0)
                    len = JsonArray2.length().toDouble()
                    for (i in 0 until len.toInt()) {
                        val JsonArray3 = JsonArray2.getJSONArray(i)
                        tv_translated_text!!.text =
                            tv_translated_text!!.text.toString() + JsonArray3.getString(0)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                  //  _snackbar("An error occurred")
                }
            }

            override fun onErrorResponse(_param1: String, _param2: String) {
                val _tag = _param1
                val _message = _param2
                _snackbar("No internet connection")
            }
        }
        adsRemoveLayout!!.setOnClickListener(View.OnClickListener { showRemoveAdsDialog(this@SanskritActivity) })
    }

    private fun loadRewardedAd() {
        progressDialog!!.show()
        val adRequest = AdRequest.Builder().build()
        RewardedAd.load(this, "ca-app-pub-7162704238713975/4767493326",
            adRequest, object : RewardedAdLoadCallback() {
                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    // Handle the error.
                    Log.d("watchAd", "onAdFailedToLoad >> $loadAdError")
                    mRewardedAd = null
                    progressDialog!!.dismiss()
                    Toast.makeText(this@SanskritActivity, "Ad failed to load.", Toast.LENGTH_LONG)
                        .show()
                }

                override fun onAdLoaded(ad: RewardedAd) {
                    mRewardedAd = ad
                    progressDialog!!.dismiss()
                    mRewardedAd!!.show(this@SanskritActivity) { rewardItem: RewardItem? ->
                        //onUserEarnedReward
                        Log.d("watchAd", "The user earned the reward.")
                        giveAdFreeAccessFor48Hours()
                    }
                }
            })
    }

    private fun showRemoveAdsDialog(context: Context) {
        val builder = AlertDialog.Builder(context)
        builder.setTitle("Remove Ads")
        builder.setIcon(R.drawable.ads)
        builder.setMessage("Remove all ads for 48 hours by watching a video ad.")
        builder.setPositiveButton("Watch Video") { dialog, which -> loadRewardedAd() }
        builder.setNegativeButton("Cancel") { dialog, which -> dialog.dismiss() }
        val dialog = builder.create()
        dialog.show()
    }

    private fun giveAdFreeAccessFor48Hours() {
        // Save the current time to SharedPreferences
        val time = System.currentTimeMillis()
        sfEditor!!.putLong(Util.KEY_adWatchedOn, time)
        sfEditor!!.apply()
        Util.showToast("Enjoy! Ads Free for 48hr", this@SanskritActivity)
        _TransitionManager(nav, 1000.0)
        template!!.visibility = View.GONE
        adsRemoveLayout!!.visibility = View.GONE
        tv_title!!.setTextColor(resources.getColor(R.color.colorAccent))
        tv_title!!.text = "Sanskrit Translator Pro"
        Log.d("watchAd", "giveAdFreeAccessFor48Hours >> $time")
    }

    private fun initializeLogic() {
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
            val w = this@SanskritActivity.window
            w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            w.statusBarColor = -0x80704
        }
        _restore_bookmarks_list()
        speaker!!.setColorFilter(-0xb9a59b)
    }

    private fun checkUpdate() {
        appUpdateManager.appUpdateInfo.addOnSuccessListener { appUpdateInfo ->
            if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE &&
                appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)) {

                // Start Immediate Update
                appUpdateManager.startUpdateFlow(
                    appUpdateInfo,
                    this,
                    AppUpdateOptions.newBuilder(AppUpdateType.IMMEDIATE).build()
                ).addOnSuccessListener {
                    // Inline access to success
                    println("Update flow started successfully.")
                }.addOnFailureListener { exception ->
                    // Inline access to failure
                    exception.printStackTrace()
                   // Toast.makeText(this, "Failed to start update: ${exception.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }.addOnFailureListener { exception ->
            // Handle failure to fetch update info
            exception.printStackTrace()
           // Toast.makeText(this, "Failed to check updates: ${exception.message}", Toast.LENGTH_SHORT).show()
        }

    }


    private fun processImage(photoBitmap: Bitmap) {

        dialog.show()

        val image = InputImage.fromBitmap(photoBitmap, 0)
        Util.log("333", this)
        recognizer!!.process(image)
            .addOnSuccessListener { visionText: Text ->

                dialog.dismiss()

                Util.log("hello322>>>" + visionText.text, this@SanskritActivity)
                et_text_translate!!.setText(visionText.text)
            }
            .addOnFailureListener { e: Exception ->
                dialog.dismiss()
                Util.showToast("❌ No Text Found..",this)
                Util.log("5555", this@SanskritActivity)
                Log.e("KEY", e.toString())
            }

    }

    override fun onActivityResult(_requestCode: Int, _resultCode: Int, _data: Intent?) {
        super.onActivityResult(_requestCode, _resultCode, _data)
        if (_requestCode == REQ_CODE_SPEECH_INPUT) {
            if (null != _data) {
                val result = _data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                et_text_translate!!.setText(result!![0].trim { it <= ' ' })
            }
        }


        //picked image
        if (_resultCode == RESULT_OK) {
            Util.log("6666", this)
            // Image Uri will not be null for RESULT_OK
            val uri = _data!!.data
            if (uri != null) {
                Util.log("111", this)
                val photoBitmap = Util.toBitmap(this, uri)
                if (photoBitmap != null) {
                    Util.log("2222", this)

                    processImage(photoBitmap)
                }
            }
        } else {
            Util.log("7777", this)
        }


    }

    override fun onBackPressed() {
        val sharedPreferences2 = getSharedPreferences("MySharedPref2", MODE_PRIVATE)
        if (sharedPreferences2.getString("rate", "") == "done") {
            super.onBackPressed()
        } else {
            cus_rate("https://play.google.com/store/apps/details?id=$packageName")
        }
    }

    private fun cus_rate(open_link: String) {
        val dialog3 = AlertDialog.Builder(this).create()
        val inflate = layoutInflater.inflate(R.layout.rating, null)
        dialog3.window!!.setBackgroundDrawableResource(android.R.color.transparent)
        dialog3.setView(inflate)
        val title = inflate.findViewById<TextView>(R.id.title_cus_dia)
        val rate = inflate.findViewById<View>(R.id.rate) as TextView
        val later = inflate.findViewById<View>(R.id.later) as TextView
        /*TextView done  = (TextView) inflate.findViewById(R.id.done);
TextView close  = (TextView) inflate.findViewById(R.id.close);
final TextView amt = (TextView) inflate.findViewById(R.id.amt);
*/
        val bg = inflate.findViewById<View>(R.id.bg) as LinearLayout
        dialog3.setCancelable(true)
        later.setOnClickListener { view: View? -> finish() }
        rate.setOnClickListener { _view: View? ->
            if (open_link != "") {
                try {
                    val `in` = Intent()
                    `in`.action = Intent.ACTION_VIEW
                    `in`.data = Uri.parse(open_link)
                    startActivity(`in`)
                    val sharedPreferences2 = getSharedPreferences("MySharedPref2", MODE_PRIVATE)
                    val myEdit = sharedPreferences2.edit()
                    myEdit.putString("rate", "done")
                    myEdit.apply()
                } catch (w: Exception) {
                    Util.showToast("Failed to open", this@SanskritActivity)
                    w.printStackTrace()
                }


                //it will rest the drop date after user click the

                // rate us button
                dialog3.dismiss()
            }
        }
        dialog3.show()
    }

    public override fun onStart() {
        super.onStart()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        if (data!!.contains("lang_from")) {
            tv_from_lang!!.text = data!!.getString("lang_from", "")
        } else {
            tv_from_lang!!.text = resources.getString(R.string.from_lang_text)
            data!!.edit().putString("lang_from", tv_from_lang!!.text.toString()).apply()
            data!!.edit().putString("lang_from_code", resources.getString(R.string.from_lang))
                .apply()
        }
        if (data!!.contains("lang_to")) {
            tv_to_lang!!.text = data!!.getString("lang_to", "")
        } else {
            //tv_to_lang.setText(Locale.getDefault().getDisplayLanguage());
            tv_to_lang!!.text = resources.getString(R.string.to_lang_text)
            data!!.edit().putString("lang_to", tv_to_lang!!.text.toString()).apply()
            //	data.edit().putString("lang_to_code", Locale.getDefault().getLanguage()).apply();
            data!!.edit().putString("lang_to_code", resources.getString(R.string.to_lang)).apply()
        }
        //Util.showToast(Locale.getDefault().getDisplayLanguage(),SanskritActivity.this);
        if (data!!.contains("lang_from") && data!!.contains("lang_to")) {
            if (et_text_translate!!.text.toString().trim { it <= ' ' } == "") {
                _TransitionManager(nav, 200.0)
                linear_translated!!.visibility = View.GONE
            } else {
                _TransitionManager(nav, 200.0)
                bookmark_visible = false
                cardview_bookmark!!.visibility = View.GONE
                text = et_text_translate!!.text.toString().trim { it <= ' ' }
                params = HashMap()
                params["User-Agent"] = "Mozilla/5.0"
                api!!.setParams(params, RequestNetworkController.REQUEST_PARAM)
                try {
                    api!!.startRequestNetwork(
                        RequestNetworkController.GET,
                        "https://translate.googleapis.com/translate_a/single?client=gtx&sl=" + data!!.getString(
                            "lang_from_code",
                            ""
                        ) + "&tl=" + data!!.getString(
                            "lang_to_code",
                            ""
                        ) + "&dt=t&q=" + URLEncoder.encode(text, "UTF-8"),
                        "a",
                        _api_request_listener
                    )
                } catch (e: Exception) {
                e.printStackTrace()
                //_snackbar("An error occurred")
                }
            }
        }
    }

    fun _TransitionManager(_view: View?, _duration: Double) {
        val viewgroup = _view as LinearLayout?
        val autoTransition = AutoTransition()
        autoTransition.duration = _duration.toLong()
        TransitionManager.beginDelayedTransition(viewgroup, autoTransition)
    }

    fun _snackbar(_text: String?) {
        Util.showToast(_text, this)
        /*Util.CustomToast(getApplicationContext(), _text, 0xFFFFFFFF, 19, 0xFF000000, 25, SketchwareUtil.BOTTOM);*/
        /*Snackbar snackbar = Snackbar.make(nav, _text, Snackbar.LENGTH_LONG);
snackbar.setDuration(2000);
snackbar.show();*/
    }

    fun _hideKeyboard() {
        val imm = this.getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        //Find the currently focused view, so we can grab the correct window token from it.
        imm.hideSoftInputFromWindow(et_text_translate!!.windowToken, 0)
    }

    fun _save_bookmark_list() {
        Util.log(Gson().toJson(listmap_bookmarks),this)
        data!!.edit().putString("bookmark", Gson().toJson(listmap_bookmarks)).apply()
    }

    fun _restore_bookmarks_list() {
        if (data!!.contains("bookmark")) {
            listmap_bookmarks = Gson().fromJson(
                data!!.getString("bookmark", ""),
                object : TypeToken<ArrayList<HashMap<String?, Any?>?>?>() {}.type
            )
            gridview!!.adapter = GridviewAdapter(listmap_bookmarks)
        }
    }

    fun _setCursorPosition(_textview: TextView?, _position: Double) {
        (_textview as EditText?)!!.setSelection(_position.toInt())
    }

    fun _setCornerRadii(
        _view: View,
        _color: String?,
        _x1: Double,
        _x2: Double,
        _x3: Double,
        _x4: Double
    ) {
        val gd = GradientDrawable()
        gd.setColor(Color.parseColor(_color))
        gd.cornerRadii = floatArrayOf(
            _x1.toInt().toFloat(),
            _x1.toInt().toFloat(),
            _x2.toInt().toFloat(),
            _x2.toInt().toFloat(),
            _x3.toInt().toFloat(),
            _x3.toInt().toFloat(),
            _x4.toInt().toFloat(),
            _x4.toInt().toFloat()
        )
        _view.background = gd
    }



    inner class GridviewAdapter(private val _data: ArrayList<HashMap<String, Any>>) : BaseAdapter() {

        override fun getCount(): Int {
            return _data.size
        }

        override fun getItem(position: Int): HashMap<String, Any> {
            return _data[position]
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            // Check if convertView is null, inflate a new view if necessary
            val view: View = convertView ?: LayoutInflater.from(parent.context)
                .inflate(R.layout.san_bookmark_item, parent, false)

            // Initialize views from the layout
            val tvText = view.findViewById<TextView>(R.id.tv_text)
            val tvTranslatedText = view.findViewById<TextView>(R.id.tv_translated_text)

            // Populate the data
            val item = _data[position]
            tvText.text = item["text"]?.toString() ?: ""
            tvTranslatedText.text = item["translate"]?.toString() ?: ""

            return view
        }
    }


    fun shareText(view: View?) {
        Util.showToast("Sharing..", this@SanskritActivity)
        Util.share_text(
            this@SanskritActivity, """${resources.getString(R.string.app_name)} translation
*Google Play Store App Link:* 
https://play.google.com/store/apps/details?id=${packageName}
                

*${tv_translated_text!!.text.toString().trim { it <= ' ' }}*

Translated from : 

*${et_text_translate!!.text.toString().trim { it <= ' ' }}*"""
        )
    }

    fun ocr(view: View?) {

        android.app.AlertDialog.Builder(this)
            .setMessage("This feature is in Beta testing and may produce inaccurate results.")
            .setCancelable(true)
            .setTitle("SANSKRIT OCR - TEST RELEASE")
            .setPositiveButton("Launch OCR"
            ) { dialogInterface, i -> ImagePicker.with(this).crop().start() }
            .setNegativeButton("Close") { dialogInterface, i ->
                dialogInterface.dismiss()
            }
            .create()
            .show()


        //Crop.pickImage(this);
    }

    companion object {
        const val REQ_CODE_SPEECH_INPUT = 1
        private const val UPDATE_CODE = 2342
    }
}
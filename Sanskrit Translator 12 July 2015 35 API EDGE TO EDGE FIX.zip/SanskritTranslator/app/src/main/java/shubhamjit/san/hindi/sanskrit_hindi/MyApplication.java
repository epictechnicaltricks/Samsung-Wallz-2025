package shubhamjit.san.hindi.sanskrit_hindi;

import android.app.Activity;
import android.app.Application;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;

import androidx.activity.ComponentActivity;
import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

public class MyApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        // Register global activity lifecycle callbacks
        registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
            @Override
            public void onActivityCreated(@NonNull Activity activity, @Nullable Bundle savedInstanceState) {
                // Only apply if activity is a ComponentActivity (AppCompatActivity, etc.)
                if (activity instanceof ComponentActivity) {
                    activity.getWindow().getDecorView().post(() -> {
                        Window window = activity.getWindow();

                        // Allow content to draw under system bars (edge-to-edge)
                        WindowCompat.setDecorFitsSystemWindows(window, false);
                        EdgeToEdge.enable((ComponentActivity) activity);

                        // Optional: Light status bar on white background
                        window.setStatusBarColor(Color.parseColor("#FFFFFF"));
                        WindowInsetsControllerCompat insetsController =
                                new WindowInsetsControllerCompat(window, window.getDecorView());
                        insetsController.setAppearanceLightStatusBars(true); // Dark icons on light background

                        // Set insets padding to root view
                        ViewGroup content = activity.findViewById(android.R.id.content);
                        if (content != null && content.getChildCount() > 0) {
                            View mainView = content.getChildAt(0);

                            ViewCompat.setOnApplyWindowInsetsListener(mainView, (v, insets) -> {
                                int systemBarsType =
                                        WindowInsetsCompat.Type.systemBars()
                                                | WindowInsetsCompat.Type.displayCutout()
                                                | WindowInsetsCompat.Type.navigationBars()
                                                | WindowInsetsCompat.Type.ime();

                                androidx.core.graphics.Insets systemBars = insets.getInsets(systemBarsType);

                                v.setPadding(
                                        systemBars.left,
                                        systemBars.top,
                                        systemBars.right,
                                        systemBars.bottom
                                );

                                return insets;
                            });

                            // Ensure insets are applied immediately (needed on API 30+)
                            ViewCompat.requestApplyInsets(mainView);
                        }
                    });
                }
            }

            // Unused lifecycle methods
            @Override public void onActivityStarted(@NonNull Activity activity) {}
            @Override public void onActivityResumed(@NonNull Activity activity) {}
            @Override public void onActivityPaused(@NonNull Activity activity) {}
            @Override public void onActivityStopped(@NonNull Activity activity) {}
            @Override public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle outState) {}
            @Override public void onActivityDestroyed(@NonNull Activity activity) {}
        });
    }
}
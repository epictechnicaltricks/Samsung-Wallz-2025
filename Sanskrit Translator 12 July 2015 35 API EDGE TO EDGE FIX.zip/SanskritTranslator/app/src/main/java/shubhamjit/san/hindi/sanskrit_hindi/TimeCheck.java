package shubhamjit.san.hindi.sanskrit_hindi;

import java.util.concurrent.TimeUnit;

public class TimeCheck {

    // Constants for time thresholds
  // private static final long ONE_HOUR_IN_MILLIS = TimeUnit.HOURS.toMillis(1);
  // private static final long ONE_DAY_IN_MILLIS = TimeUnit.DAYS.toMillis(1);

 /*   public static boolean is48HoursCompleted(long timeInMillisToCheck, long previousCheckTimeInMillis) {
        long currentTimeInMillis = System.currentTimeMillis();

        // Check if the time suddenly changed by 1 hour or 1 day
        if (Math.abs(currentTimeInMillis - previousCheckTimeInMillis) >= ONE_HOUR_IN_MILLIS) {
            System.out.println("Warning: Time changed by 1 hour or more.");
        }

        if (Math.abs(currentTimeInMillis - previousCheckTimeInMillis) >= ONE_DAY_IN_MILLIS) {
            System.out.println("Warning: Time changed by 1 day or more.");
        }

        // Calculate the difference in milliseconds
        long diffInMillies = currentTimeInMillis - timeInMillisToCheck;

        // Convert milliseconds to hours
        long diffInHours = TimeUnit.MILLISECONDS.toHours(diffInMillies);

        // Check if 48 hours have passed
        return diffInHours >= 48;
    }*/

    public static boolean is48HoursCompleted(long timeInMillisToCheck) {
        long currentTimeInMillis = System.currentTimeMillis();

        // Calculate the difference in milliseconds
        long diffInMillies = currentTimeInMillis - timeInMillisToCheck;

        // Convert milliseconds to hours
        long diffInHours = TimeUnit.MILLISECONDS.toHours(diffInMillies);

        // Check if 48 hours have passed
        return diffInHours >= 48;
    }

  /*  public static void main(String[] args) {
        // Example usage
        long timeInMillisToCheck = System.currentTimeMillis() - TimeUnit.HOURS.toMillis(50); // 50 hours ago
        long previousCheckTimeInMillis = System.currentTimeMillis() - TimeUnit.MINUTES.toMillis(10); // 10 minutes ago

        if (is48HoursCompleted(timeInMillisToCheck, previousCheckTimeInMillis)) {
            System.out.println("48 hours have been completed.");
        } else {
            System.out.println("48 hours have not been completed yet.");
        }
    }*/
}

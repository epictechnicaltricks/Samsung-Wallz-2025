package shubhamjit.san.hindi.sanskrit_hindi

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.os.Build
import android.view.View
import android.widget.FrameLayout
import android.widget.ProgressBar
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder

object Utils {

    fun showMaterialProgressBarDialog(context: Context): androidx.appcompat.app.AlertDialog {
        val frameLayout = FrameLayout(context)
        val padding = 48 // Padding in pixels
        frameLayout.setPadding(padding, padding, padding, padding)

        val progressBar = ProgressBar(context)
        progressBar.isIndeterminate = true

        // Set progress bar tint color to black
        progressBar.indeterminateTintList = ColorStateList.valueOf(Color.BLUE)

        frameLayout.addView(progressBar)

        val builder = MaterialAlertDialogBuilder(context)
            .setTitle("TEXT SCAN PROGRESS..")
            .setView(frameLayout)
            .setCancelable(false)

        return builder.create()
    }



}
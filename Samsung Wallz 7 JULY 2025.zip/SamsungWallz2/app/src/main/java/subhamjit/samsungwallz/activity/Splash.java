package subhamjit.samsungwallz.activity;


import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.airbnb.lottie.LottieAnimationView;

import subhamjit.samsungwallz.DateUtils;
import subhamjit.samsungwallz.R;

public class Splash extends AppCompatActivity {

    TextView title;
    LottieAnimationView animationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        title = findViewById(R.id.title22);
        animationView = findViewById(R.id.animationView);



        SharedPreferences sharedPreferences2 = getSharedPreferences("MySharedPref2", MODE_PRIVATE);
        final SharedPreferences.Editor myEdit = sharedPreferences2.edit();

        if(sharedPreferences2.getString("premium","").equals("true")) {


            long tyu = DateUtils.getTimeDifference(
                    DateUtils.getCurrentTime()
                    ,sharedPreferences2.getString("premium_upto_time","")
            );



           Log.d("AD2123", ""+tyu+" hr left for remove premium");


            if(tyu<=0)
            {
                // premium ended
                myEdit.putString("premium", "false");
                myEdit.putString("premium_end_show", "true");
                myEdit.putString("premium_show_first", "");


            }else {

                myEdit.putString("premium_end_show", "false");
                myEdit.putString("time_left_hr", tyu+"");
            }

            myEdit.apply();

            animationView.setVisibility(View.VISIBLE);
            animationView.playAnimation();

            // premium
            title.setText(Html.fromHtml("<p>"+getResources().getString(R.string.title)+"<br><font color='#8A5BDF' size='1'>Premium</font></p>"));



        }else {


            myEdit.putString("premium", "false");
            myEdit.apply();


            animationView.setVisibility(View.GONE);
            animationView.pauseAnimation();
            // no premium
            title.setText(Html.fromHtml(getResources().getString(R.string.title)));

        }



        Window w = getWindow(); // in Activity's onCreate() for instance
        w.setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);


        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(Splash.this, MainActivity.class));

                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                finish();
            }
        }, 3000);
    }
}
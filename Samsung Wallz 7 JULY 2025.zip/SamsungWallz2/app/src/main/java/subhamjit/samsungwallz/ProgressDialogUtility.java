package subhamjit.samsungwallz;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;

public class ProgressDialogUtility {
    private ProgressDialog progressDialog;

    public ProgressDialogUtility(Context context) {
        progressDialog = new ProgressDialog(context,  AlertDialog.THEME_DEVICE_DEFAULT_DARK);
        progressDialog.setMessage("Hold on 😉");
        progressDialog.setCancelable(false); // Prevent canceling by touching outside
    }

    /**
     * Show the progress dialog
     */
    public void show() {
        if (progressDialog != null && !progressDialog.isShowing()) {
            progressDialog.show();
        }
    }

    /**
     * Hide the progress dialog
     */
    public void hide() {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }
}

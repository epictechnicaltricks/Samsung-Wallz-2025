package subhamjit.samsungwallz.frags;

import static android.content.Context.MODE_PRIVATE;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Vibrator;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Objects;

import eightbitlab.com.blurview.BlurView;
import eightbitlab.com.blurview.RenderScriptBlur;
import subhamjit.samsungwallz.DateUtils;
import subhamjit.samsungwallz.R;
import subhamjit.samsungwallz.Util;
import subhamjit.samsungwallz.activity.ShowWallz;
import subhamjit.samsungwallz.activity.Splash;


public class Fragment_home extends  Fragment  {
	
	

	private RecyclerView recyclerview1/*,recyclerview2_shimmer*/;

	private final ArrayList<HashMap<String, Object>> home_wallz_list = new ArrayList<>();

	String[] dummy_for_shimmer= new String[]{"", "", "","","",""};

	//ShimmerFrameLayout container;
	// Shimmer effect

	ImageView menu, adsRemove;
	Activity mContext;


    ArrayList<HashMap<String, Object>> fav_img_list = new ArrayList<>();

    SharedPreferences sf;
    SharedPreferences.Editor myEdit;
    int pos;

	Handler h;
	TextView title;

	//////////////////////////////////


	private RewardedAd rewardedAd;
	private static final String TAG = "AD2123";

	ProgressDialog progressDialog;

	/////////////////////




	/////////////////
	TextView left_time;


	@NonNull
	@Override
	public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
		View _view = _inflater.inflate(R.layout.home_fragment, _container, false);
		initialize(_view);
		return _view;
	}

	@Override
	public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
		initializeLogic();
		super.onViewCreated(view, savedInstanceState);

	}

	private void initialize(View _view) {

		progressDialog = new ProgressDialog(requireActivity(), AlertDialog.THEME_DEVICE_DEFAULT_DARK);
		progressDialog.setMessage("Loading video ad...");
		progressDialog.setCancelable(true);
		mContext = requireActivity();

		h = new Handler();

		left_time = _view.findViewById(R.id.left_time);

		title = _view.findViewById(R.id.title);

		menu = _view.findViewById(R.id.menu_);
		adsRemove = _view.findViewById(R.id.adsRemove);

		recyclerview1 = _view.findViewById(R.id.recyclerview1);
		//recyclerview2_shimmer = _view.findViewById(R.id.recyclerview2_shimmer);

		recyclerview1.setLayoutManager(new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL));
	//	recyclerview2_shimmer.setLayoutManager(new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL));


		sf =  requireActivity().getSharedPreferences("MySharedPref2", MODE_PRIVATE);
        myEdit = sf.edit();

		//container = _view.findViewById(R.id.shimmer_view_container);

		menu.setOnClickListener(view -> menuOnClick());









		adsRemove.setOnClickListener(view -> remove_Ad_dialog());

	}

	public void menuOnClick() {

		info_dialog();

	}



	public class HomeAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>
	{

	ArrayList<HashMap<String, Object>> data;

	public HomeAdapter(ArrayList<HashMap<String, Object>> _array) {
		data = _array;
	}

	@NonNull
	@Override
	public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
		//LayoutInflater inflate_ = getLayoutInflater();
		//View v = inflate_.inflate(R.layout.wall_custom_layout, , false);
		//return new ViewHolder(v);

		LayoutInflater inflater = (LayoutInflater) requireContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View v = inflater.inflate(R.layout.wall_custom_layout, null);
		RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		v.setLayoutParams(lp);
		return new ViewHolder(v);


	}

	@Override
	public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
		View _view = viewHolder.itemView;

		final ImageView wall = _view.findViewById(R.id.wall_img);
		final CardView card = _view.findViewById(R.id.cardview1);
		final  ImageView fav = _view.findViewById(R.id.fav_btn);



		int ran= Util.getRandomNo(1, 5);
		if (ran == 1) {       wall.setBackgroundColor(0xFF89039e);
		} else if(ran  == 2){ wall.setBackgroundColor(0xFF039e72);
		}else if(ran == 3){  wall.setBackgroundColor(0xFF035b9e);
		}else if(ran == 4){  wall.setBackgroundColor(0xFF9e0d03);
		}else if(ran == 5) { wall.setBackgroundColor(0xFF46039e);
		}






		Animation slide_up = AnimationUtils.loadAnimation(getActivity(),
				R.anim.slide_up );
		card.startAnimation(slide_up);





		final String img = Objects.requireNonNull(home_wallz_list.get(i).get("image")).toString();
		Glide.with(requireActivity()).load(Uri.parse(img))
				//.transition(withCrossFade())
				.listener(new RequestListener<Drawable>() {
					@Override
					public boolean onLoadFailed(@Nullable GlideException e, Object o, Target<Drawable> target, boolean b) {
						return false;
					}

					@SuppressLint("SuspiciousIndentation")
					@Override
					public boolean onResourceReady(Drawable drawable, Object o, Target<Drawable> target, DataSource dataSource, boolean b) {
						// If auto-start is set to false
						//if(viewHolder.getAdapterPosition()==4)
					//	container.stopShimmer();
						return false;
					}
				})
				.thumbnail(0.01f).into(wall);



        //////////////////////////////////////////


		if(sf.getString("fav_data","").contains(img)) {
			Glide.with(mContext).load(R.drawable.fav_filled).into(fav);

		}
        else {
			Glide.with(mContext).load(R.drawable.fav_outline).into(fav);
        }

		card.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {


				Intent i = new Intent();
				i.setClass(getContext(), ShowWallz.class);
				i.putExtra("wallz_url",img);

				if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
					Util.setActivityAnimation(card, "shubham",getActivity(),i);

				} else {

					startActivity(i);
				}
			}
		});
        ////////////////////////////////////////


		fav.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {

                HashMap<String, Object>  new_map = new HashMap<>();

                fav_img_list = new Gson().fromJson(sf.getString("fav_data",""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());

                pos = getPos_img_url(img,fav_img_list);

                    if(pos>=0)
                    {


						Glide.with(mContext).load(R.drawable.fav_outline).into(fav);

                        fav_img_list.remove(pos);

						Toast.makeText(getContext(), "Removed", Toast.LENGTH_SHORT).show();


                        Log.d("fav1",fav_img_list.size()+"\n"+ fav_img_list+"\npos -"+pos);

                    } else {


						Glide.with(mContext).load(R.drawable.fav_filled).into(fav);

                        new_map.put("img_url",img);
						new_map.put("img_id","0");
                        fav_img_list.add(new_map);

						Vibrator vb = (Vibrator)   getActivity().getSystemService(Context.VIBRATOR_SERVICE);
						vb.vibrate(100);


						Toast.makeText(getContext(), "Added to Favs", Toast.LENGTH_SHORT).show();


                    }
                myEdit.putString("fav_data",new Gson().toJson(fav_img_list));
                myEdit.apply();


            }
		});

	}




	@Override
	public int getItemCount() {
		return data.size();
	}

	public class ViewHolder extends RecyclerView.ViewHolder {
		public ViewHolder(View v) {
			super(v);
		}
	}

}


     public class ShimmerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

		String[] data;

		public ShimmerAdapter(String[] _array) {
			data = _array;
		}

		@NonNull
		@Override
		public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {


			LayoutInflater inflater = (LayoutInflater) requireContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View v = inflater.inflate(R.layout.wall_custom_layout, null);
			RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			v.setLayoutParams(lp);
			return new ViewHolder(v);


		}

		@Override
		public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i)
		{

			View _view = viewHolder.itemView;



		}




		@Override
		public int getItemCount() {
			return data.length;
		}

		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}

	}

    int getPos_img_url(String img_url, ArrayList<HashMap<String, Object>> arrayList)
    {

        for(int x=0; x<arrayList.size(); x++)
        {
            if(Objects.requireNonNull(arrayList.get(x).get("img_url")).toString().trim().equals(img_url.trim()))
            {
                return x;
            }
        }

        return -1;
    }




	@Override
	public void onResume() {




		SharedPreferences sharedPreferences2 = requireActivity().getSharedPreferences("MySharedPref2", MODE_PRIVATE);





		if(sharedPreferences2.getString("premium","").equals("true")) {




			left_time.setText(sharedPreferences2.getString("time_left_hr","47")+"hr\nAds-free");
			left_time.setVisibility(View.VISIBLE);
			/*if(sharedPreferences2.getString("time_left_hr","").equals("")) {
				left_time.setVisibility(View.GONE);
			}else {

			}*/

			adsRemove.setVisibility(View.GONE);

		}else {


			if(sharedPreferences2.getString("premium_show_first","").equals("true")) {
				remove_Ad_dialog();
			}





			if(sharedPreferences2.getString("premium_end_show","").equals("true")) {
				remove_Ad_ended();
			}


			left_time.setVisibility(View.GONE);

			adsRemove.setVisibility(View.VISIBLE);

			Glide.with(requireActivity()).load(R.drawable.crown12)
					.thumbnail(0.01f)
					.into(adsRemove);
		}


		super.onResume();
	}



	private void initializeLogic() {



		recyclerview1.setVisibility(View.GONE);
		//container.startShimmer();

		//recyclerview2_shimmer.setVisibility(View.VISIBLE);


		recyclerview1.setVisibility(View.VISIBLE);
		//recyclerview2_shimmer.setVisibility(View.GONE);
		//dummy_for_shimmer =  new String[0];

		h.postDelayed(() ->
		{
			//container.stopShimmer();
			/*final Animation fade_in = AnimationUtils.loadAnimation(getActivity(),
					R.anim.fade_in);
			recyclerview1.startAnimation(fade_in);*/



		}, 2000);





		wall_data();

		//Collections.reverse(home_wallz_list);

		if(sf.getString("fav_data","").equals(""))
		{
			myEdit.putString("fav_data","[]");
			myEdit.apply();
		}

		fav_img_list = new Gson().fromJson(sf.getString("fav_data",""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());


	//	recyclerview2_shimmer.setAdapter(new ShimmerAdapter(dummy_for_shimmer));
		recyclerview1.setAdapter(new HomeAdapter(home_wallz_list));
		//Collections.shuffle(home_wallz_list);
		Log.d("wall",home_wallz_list.toString());








		Log.d("fav1-resume",fav_img_list.size()+"\n"+ fav_img_list+"\npos -"+pos);

	}




	void wallpaper_map(final String wall_url_) {
		HashMap<String, Object > wallpaper_map_ = new HashMap<>();
		wallpaper_map_.put("image", wall_url_);
		home_wallz_list.add(wallpaper_map_);
	}
	
	@Override
	public void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
        super.onActivityResult(_requestCode, _resultCode, _data);

	}




	private void remove_Ad_dialog() {


		try {
			final androidx.appcompat.app.AlertDialog dialog3 = new androidx.appcompat.app.AlertDialog.Builder(getActivity()).create();
			View inflate = getLayoutInflater().inflate(R.layout.remove_ad,null);

			dialog3.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
			dialog3.setView(inflate);


			final TextView rate = (TextView) inflate.findViewById(R.id.rate);
			final TextView later = (TextView) inflate.findViewById(R.id.later);
			final TextView msg = (TextView) inflate.findViewById(R.id.msg22);

			msg.setText(Html.fromHtml("Get <b>Ad-free</b> experience for <b>48 hrs! 🤩</b>"));

			BlurView blurView = inflate.findViewById(R.id.blurView);
			float radius = 14f;

			View decorView = getActivity().getWindow().getDecorView();
			ViewGroup rootView = (ViewGroup) decorView.findViewById(android.R.id.content);

			Drawable windowBackground = decorView.getBackground();

			blurView.setupWith(rootView, new RenderScriptBlur(getActivity())) // or RenderEffectBlur
					.setFrameClearDrawable(windowBackground) // Optional
					.setBlurRadius(radius);



			dialog3.setCancelable(false);



			later.setOnClickListener(view -> {
				SharedPreferences sharedPreferences2 = getActivity().getSharedPreferences("MySharedPref2", MODE_PRIVATE);
				final SharedPreferences.Editor myEdit = sharedPreferences2.edit();
				myEdit.putString("premium_show_first", "false");
				myEdit.apply();

				dialog3.dismiss();


			});


			rate.setOnClickListener(_view -> {

				loadRewardedAd();


				dialog3.dismiss();

			});
			dialog3.show();
		}catch (Exception e)
		{

		}


	}

	private void remove_Ad_ended() {


		try {
			final androidx.appcompat.app.AlertDialog dialog3 = new androidx.appcompat.app.AlertDialog.Builder(getActivity()).create();
			View inflate = getLayoutInflater().inflate(R.layout.remove_ad_ended,null);

			dialog3.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
			dialog3.setView(inflate);


			final TextView rate = (TextView) inflate.findViewById(R.id.rate);
			final TextView later = (TextView) inflate.findViewById(R.id.later);
			final TextView msg = (TextView) inflate.findViewById(R.id.msg22);

			msg.setText(Html.fromHtml("Get <b>Ad-free</b> experience again for <b>48 hrs </b> just watch an ad!"));

			BlurView blurView = inflate.findViewById(R.id.blurView);
			float radius = 14f;

			View decorView = getActivity().getWindow().getDecorView();
			ViewGroup rootView = (ViewGroup) decorView.findViewById(android.R.id.content);

			Drawable windowBackground = decorView.getBackground();

			blurView.setupWith(rootView, new RenderScriptBlur(getActivity())) // or RenderEffectBlur
					.setFrameClearDrawable(windowBackground) // Optional
					.setBlurRadius(radius);



			dialog3.setCancelable(false);



			later.setOnClickListener(view -> {
				SharedPreferences sharedPreferences2 = getActivity().getSharedPreferences("MySharedPref2", MODE_PRIVATE);
				final SharedPreferences.Editor myEdit = sharedPreferences2.edit();
				myEdit.putString("premium_end_show", "false");
				myEdit.apply();

				dialog3.dismiss();


			});


			rate.setOnClickListener(_view -> {
				loadRewardedAd();
				dialog3.dismiss();

			});
			dialog3.show();
		}catch (Exception e)
		{

		}

	}

	private void info_dialog() {
		final androidx.appcompat.app.AlertDialog dialog3 = new androidx.appcompat.app.AlertDialog.Builder(getActivity()).create();
		View inflate = getLayoutInflater().inflate(R.layout.info_dialog,null);

		dialog3.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		dialog3.setView(inflate);


		final TextView rate = (TextView) inflate.findViewById(R.id.rate);
		final TextView later = (TextView) inflate.findViewById(R.id.later);
		final TextView msg = (TextView) inflate.findViewById(R.id.msg22);

		msg.setText(Html.fromHtml("<b>"+getResources().getString(R.string.title)+"</b> app: A lite, fast and user-friendly wallpaper application offering a vast collection of high-quality wallpapers. <br><br>Developed by Shubhamjit<br>Made with ♥ in Odisha, India<br><br><a href='https://www.termsfeed.com/live/afcc5eb8-19be-4349-a4e8-be1322301e0b'>Privacy Policy</a><br>"));
		msg.setMovementMethod(LinkMovementMethod.getInstance());

		BlurView blurView = inflate.findViewById(R.id.blurView);
		float radius = 14f;

		View decorView = getActivity().getWindow().getDecorView();
		ViewGroup rootView = (ViewGroup) decorView.findViewById(android.R.id.content);

		Drawable windowBackground = decorView.getBackground();

		blurView.setupWith(rootView, new RenderScriptBlur(getActivity())) // or RenderEffectBlur
				.setFrameClearDrawable(windowBackground) // Optional
				.setBlurRadius(radius);



		dialog3.setCancelable(true);



		later.setOnClickListener(view -> {
			Intent inn2 = new Intent(Intent.ACTION_VIEW);
			inn2.setData(Uri.parse("https://play.google.com/store/apps/details?id="+getActivity().getPackageName()));
			startActivity(inn2);
			dialog3.dismiss();


		});


		rate.setOnClickListener(_view -> {

			dialog3.dismiss();

		});
		dialog3.show();
	}

	private void congratulation_dialog() {
		final androidx.appcompat.app.AlertDialog dialog3 = new androidx.appcompat.app.AlertDialog.Builder(getActivity()).create();
		View inflate = getLayoutInflater().inflate(R.layout.remove_ad_success,null);

		dialog3.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		dialog3.setView(inflate);


		final TextView rate = (TextView) inflate.findViewById(R.id.rate);
		final TextView later = (TextView) inflate.findViewById(R.id.later);
		final TextView msg = (TextView) inflate.findViewById(R.id.msg22);

		msg.setText(Html.fromHtml("Enjoy <b>Ad-free</b> experience for <b>48 hrs! </b>"));

		BlurView blurView = inflate.findViewById(R.id.blurView);
		float radius = 14f;

		View decorView = getActivity().getWindow().getDecorView();
		ViewGroup rootView = (ViewGroup) decorView.findViewById(android.R.id.content);

		Drawable windowBackground = decorView.getBackground();

		blurView.setupWith(rootView, new RenderScriptBlur(getActivity())) // or RenderEffectBlur
				.setFrameClearDrawable(windowBackground) // Optional
				.setBlurRadius(radius);



		dialog3.setCancelable(false);



		later.setOnClickListener(view -> {
			dialog3.dismiss();


		});


		rate.setOnClickListener(_view -> {

			requireActivity().finish();
			startActivity(new Intent(requireActivity(), Splash.class));

			dialog3.dismiss();

		});
		dialog3.show();
	}







	private void loadRewardedAd() {
		progressDialog.show();

		AdRequest adRequest = new AdRequest.Builder().build();
		RewardedAd.load(mContext, "ca-app-pub-7162704238713975/7437031140",
				adRequest, new RewardedAdLoadCallback() {
					@Override
					public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
						// Handle the error.
						Log.d("watchAd", "onAdFailedToLoad >> " + loadAdError);
						Log.d(TAG, loadAdError.getMessage());
						rewardedAd = null;
						progressDialog.dismiss();
						Toast.makeText(mContext, "Ad failed to load.", Toast.LENGTH_LONG).show();

					}

					@Override
					public void onAdLoaded(@NonNull RewardedAd ad) {
						rewardedAd = ad;
						Log.d(TAG, "onAdLoaded");
						progressDialog.dismiss();



						rewardedAd.show(mContext, rewardItem -> {
							// Handle the reward.
							Log.d(TAG, "The user earned the reward.");
							progressDialog.dismiss();

							String current_date = null;
							try {
								current_date = DateUtils.addTwoDays(DateUtils.getCurrentTime());
							} catch (ParseException e) {
								e.printStackTrace();
							}
							SharedPreferences sharedPreferences2 = getActivity().getSharedPreferences("MySharedPref2", MODE_PRIVATE);
							final SharedPreferences.Editor myEdit = sharedPreferences2.edit();
							myEdit.putString("premium", "true");
							myEdit.putString("premium_upto_time", current_date);
							myEdit.putString("premium_end_show", "false");
							myEdit.apply();

							congratulation_dialog();

							Log.d(TAG, "AFTER  2 DAYS __ "+current_date+" The user earned the reward.");
							//int rewardAmount = rewardItem.getAmount();
							//String rewardType = rewardItem.getType();
						});

					}
				});


	}






	void wall_data()
	{




		//S25
		wallpaper_map( "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjZ-NDQ2Rer5gHx2iGc2XWE9Lw1JsWHlmLq1dUy4ovGPiIkfcToAtHwWCoMLsy0yX6urY4nbAWEe4vr4kOc0tzC3bYJnAMIVRm4aryUmJySgM2atOg16EPVqFn9HaBJsHYognyVvmwz-BEo-0NydkwSYuZJufI2Qwih_ibQTc3wkNhXKW6UPBtdoEdE7_4/s16000/Galaxy%20S25%20Wallpaper%20Ice%20Blue_1736412411211.webp");

		wallpaper_map( "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjWvTtzjrnD1kwSGs2kcW0Bc1xHLq8U-UAh87ENjUAEvYiAoPvJ6rzDoLoxl4mLvCHFRwXXHlFCea4OOmvU_doW8viRLvQPPfTeMIChWZWgx6rCApeZXnCjxAz7RVhDzUf15QFnvC6rtE0Gwpj8bk3e53lUpxouvJmtLZqewTTyKcIqJh8IoBZWZvxYd84/s16000/Galaxy%20S25%20Wallpaper%20Dark_17364125109882.webp");

		wallpaper_map( "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgY238pHpdPdtzdC4MVzrb8JNz_6aR0ujOd2Zvy9mJNi1FLDE0tEPcHU0M4XOM3QHLnvwzKjay7YNW-VSl5rNIEHRV9oaahfshA_8QXV0ryVfDt09MX1MOMeu9EC7WctYduZEhMyJi76P8dt6-T090pbc7gyuxxPRRLN7E3kmUFT7CIdEs8twLIQ91agwQ/s16000/Galaxy%20S25%20Wallpaper%20Dark_1736412510988.webp");

		wallpaper_map( "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEh5AkwRCKwWtgpErN7DyEpt4EEW0jcs68I4Rg_Ck-pm_-pQgjvCakeSOWjD6KdAgf4CjsnAMDHAB1PO0lUeU2f9iC-5kAaX3GKxLD-i3Y0c6N8X1lOSSqLtoE-ssF26ERHD6pxKjUk_xcQ5RobDtsaSgXvBkv81QEuITKxt-onpNirs8588Y3gI_PnujN4/s16000/Galaxy%20S25%20Wallpaper%20Ice%20Blue_1736412411211~2.jpg");



		//S24
		wallpaper_map( "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEh9dVjsEclI62t863bWXEfGkFgvt1yPJeiYYDDCC1xxR7Yj40ImTIP8iw1bB2eUqCt7J61uPgAX_NEeAbRzKLLsKSFTrY2Cd0bDUA-Uy8ZiV4jp6orHlKAX21c5xYEmXyb7N_0hs-5uBWGQq7eBIi1poJ-qC7Vma8V9PK-YfDmr24lvy-cKmOtdtwjHsVA/s16000/Samsung%20Galaxy%20S24%20Ultra%20One%20UI%20Wallpaper%201%20YTECHB.webp");
		wallpaper_map( "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiDvNHhEI5LyjL6CjqaYSRnb97F2Q3NEuq4zZO-8BcVkUMytz5WJjmpG3c-LQljGAH5QeQjiAU9A0r71LobrtTMHIcFZnuZq7ssp83QEo34WYc6Atz6BXZAaTXRIK4Trla71APXTOpDz8mN0-qiUoA3kP_UXXl9g4M_ycg-bt7HEGxqq40yc-tq64gqiVU/s16000/Samsung%20Galaxy%20S24%20Ultra%20One%20UI%20Wallpaper%202%20YTECHB.webp");
		wallpaper_map( "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjjSrlrwZeWuq9L8abyH5e7inRghacPi6ZtRzSU5tXdk6wNjZHi__uj0S1mPAOHHzUMAx0hyGyGOKHZuh5AAZU9AN_IU8nRbyO_3IsZdI21i-MAR7EZTDZiXLX8dgTkzGgWqPut8gIwJ1YNuHPPl17L1RVQ6j9Rpl_7LcwXElYKEA2dvdOBSbKxC87L-ho/s16000/Samsung%20Galaxy%20S24%20Ultra%20Wallpaper%203%20YTECHB.webp");
		wallpaper_map( "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEja04Plp5WBmh8wkX50DQFHj7yLwYCXkwc_-whH_WgtPOoE4LjRa6PUsCACqn_wiNdOnSJtpIgG2Gtgg4bg3eyLDi8uAcgpvjDHuzk4n4fXrO1FiexRVrJyXnmTiEOezwWGHFJ0LG3ky-St22-TMgFwyLfxDlpoTh2vLRfvAUshhzalQnOTSWzFiGZB1Rk/s16000/Samsung%20Galaxy%20S24%20Ultra%20Wallpaper%204%20YTECHB.webp");
		wallpaper_map( "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhW0KX56EnUZCAsmO4BxCarlasEJFdkWnjbZRvStvfbQZiQdZT7Huz3TuuaA2OwCCFr9lKzaCEHVW60CwDCDeiNTHCX8YIyi6P1xYS9tLTMiFTy3zOi7clhuZUnge3feaJ8aFWyKxupM4P6cm8c-3hUssr4XQneIJoBpG9Jcjvc3ik92Zlf0eSDaa3tNPU/s16000/Samsung%20Galaxy%20S24%20Ultra%20Wallpaper%205%20YTECHB.webp");
		wallpaper_map( "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEie9-OSytN1-_xcYSnaC5OJ6n0Kd1OjpIgWJMJ744_lhYlOlgOBr7DIImv5Yt7UVewRiOIItSdeacXec90E9_JVKh6oPV0ArvV5gC_0jiBfCYEBAbJcY7mWFqGBqmbI7D-KHXW92kfsfZR7dxPRpcEJcsyropghvCW6N5o9zzVo4yHuEhyphenhyphenFtqyfM3j_WIY/s16000/Samsung%20Galaxy%20S24%20Ultra%20Wallpaper%206%20YTECHB.webp");
		wallpaper_map( "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhE3prFInXbaEzICIlBtHHa4iGpwJZiNN1KQUhhzY9FQagOXVRklLmSq-6q4wVf0HBtpxxwXGkViMmZSCCgTOZdNuyEx06E5khzvAxh7FSKWU6JOuovjm-BR6QS4IOHb4NpZWDptsbJtv5apHUWZeFwCLWhgomPZTPRduzlyAivHvVEN5hcabLXQ2PQKEk/s16000/Samsung%20Galaxy%20S24%20Ultra%20Dex%20Wallpaper%202%20YTECHB.webp");
		wallpaper_map( "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhtvPx3njFfNRzOIAoIevDR6dx8wHs81DUl7lWLg9jPtkyE8ud6tJrBRfckv7w2B9F9bwRQJDWlr4MkzIJWpAy45SSbYSai8i7OFZsJjT6pUMbb3TjZamYOw5v8GhPZMNvfFXo1qtR_auBGrnyL-QO59g7iM3_WyJiOlLQHwkJRwwVNAtcgjtkRrWxrmSk/s16000/Samsung%20Galaxy%20S24%20Ultra%20Wallpaper%205%20YTECHB.webp");
		wallpaper_map( "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjVKEHvy4_HV0dqKn7E_ElNOISFcpsg5h66FbVhT9ZCVfOVWEUZENhYbyYHk_6RRZULiG7UzvMtrFoIbHzF1LHDJ2uqN5Lmu3iNE9qr2q_bRwN7ucWQPhb2MMeOW8XDv9mgIBCNqb2zhINdPizTQeEMzIIqUInCFzDlSM7qnZiGwgF-_Zm9O5P8vVXcZeo/s16000/Samsung%20Galaxy%20S24%20Ultra%20Wallpaper%207%20YTECHB.webp");




		wallpaper_map( "https://blogger.googleusercontent.com/img/a/AVvXsEiD-JQ3Y802mwBhVii9OF8vUjetx98lxuCMjUU1ynnFyni10ZedYDO3RlLiJBviOgR_5U4i1S5i1rgIxcA-Rdwpk552lfFq7MAr8QwWCvxC2iQAy9EsPJqnqJ2J96KRQSG_mOSRS1Uxutg5-IYZXjKCFuP7iQkVFFPdysxMyajkdSKUQQ4YkgLG_qzs=s1560");
		wallpaper_map( "https://blogger.googleusercontent.com/img/a/AVvXsEi_Xe1h4eQhf50L01IEsoBW0CItvr6di_NTBFOuoSHIEyM0vqbVTbwoxtIV6GEREzwcfSFKd0G7IUMjCT06nx3tP4DJ5xq6Zn7IQzkX5e569_ZKeonQKboKbcFmnRL8IxTiukvWvlTP6rFBJTW-XY-MHF8iSNqSvBaH96HGoVijP5nTcfLe0521DQyA=s1560");
		wallpaper_map( "https://blogger.googleusercontent.com/img/a/AVvXsEjwfDJxh2QQzXgphdbgB7t2YG_yK1ZP_ehwWJMnZbX6ACyJ2UTDd16GneKuBvCeA3NKML2EcZ2fWThNsI6FyPqdoiTvyu8tzPPy6FRdRNuGdZ_zo6I8oPmRsPfGoVBdv1hLG-KMHx4MAGGLzA9XvJStK22elP8AgMd_34sbYcd-cdKi89B_XKIEfR6i=s1560");
		wallpaper_map( "https://blogger.googleusercontent.com/img/a/AVvXsEiVOtEQIxf5LsTuUVdaLlh0yVNXFHNBcuwT8YNkb4EFz-fqncxRuGJ00IaHBD0pyLaYN1m3e8ZgwGxAuXIZk-OxtjKM_81FwKgOVwSIaVOQJ80OYxhi2lNHw2oAV_bixspIGmUlTTlZCUrUrMKF0sO3kG0MQJv6oM9m8evZOifEJI8oV82G8_OBkAvP=s1560");
		wallpaper_map( "https://blogger.googleusercontent.com/img/a/AVvXsEgnUWlcq2mvXQxtTpxKgOUcxUbMWgmt-bgZagTjalMgaJDACwBnctLW3VNfQBcsV741zWxGKGbRyHI-wpRJUR43pQCk56e5RNuUFbrFbOkgEj5OF0twDqDWj_xsZMDJtW1-375u5eg8A8DAF7tS4y8ot7mVg8-Snys6wCpCh578ppg2DTRlOkW7kC2h=s1560");
		wallpaper_map( "https://blogger.googleusercontent.com/img/a/AVvXsEg6OY6CKIUeisvkCRB00iWMDLLJfdWM7OAmmVKYylwWvjAfEZ57L0c1zna-kesWuzE8P8-U8QNHMfjuCaklWPY_WqqYDk-revFs6lSUHLbmfGU3KQyNPJtaSo-mLPfzLo6mKUKOVvX7XIZavJd3Q7in-0_r4wp4oqTk1Oji0OEqJHeosldlpNaSHqEE=s1560");
		wallpaper_map( "https://blogger.googleusercontent.com/img/a/AVvXsEixilxyZNHuJ1AdCAcsFH9EG3TJEg4IEiWkbyh5cCUNYp76YxQRoQZavLIh1G_Ay20syk_eredWNlaE1JbPrfHabw9FwovB2f4AnJOFZ-DS4O-YSItYpRPUhvi7U-aqCtsHfX8mKR2INnexSOLuAqME0Mso97482NKk5Fyb0MOHab66gTP7N_MzYWdu=s1560");
		wallpaper_map( "https://blogger.googleusercontent.com/img/a/AVvXsEi2gKtjzf9PRs0Y6evZVJxBh-bfgBlypLKVQDrXchzmh8JvypbCNo1d-QPXfA5etKQ1-IQcFf1w6m8Ta_7ec3eazlBke4ZwF502_K5_V0zSxi3jVTqCbIk6Mt8kXVxi-zgGl9tR3Mvc3JXWYPxzYazkKsNX7mjqP98H1nIGjFIpDEt4kEYimeSj8bnT=s1560");
		wallpaper_map( "https://blogger.googleusercontent.com/img/a/AVvXsEjm_152v1eQJMJpNT1qKJsNHAhe1wU37zmKVvJMztasIdmJtF3KRVAuNCIpKMP9nUB5-r0JxjOGEOmJJEiSA4l0gQv1M9kUk7VrzoV8nDGbY9IBzEIo2SMZfQvEGmb4dK3RRKr-tlsMdcIeS1dSAOCyTi7DvrvAQI4hEYcX6Tge8r-FksUrkJWQYNYx=s1560");
		wallpaper_map( "https://blogger.googleusercontent.com/img/a/AVvXsEh1j96dHyVeXcqa4Ar_gr49GexHSgE1uuC_SHs2kGQ9FIQ_xlv5JDxuiYaRZhYmq99VcPzBmNY1Ulyl9y5ntm3EffyI1ZFkmb9v_Y0ia4Zkf2uQK2Hg5Sns475EYUtNU9G0h5s0aMaOglv-3yzgsAfyNkNb7Kzp1o15qMakH11vIf1BRtJOdwUKRszC=s1560");
		wallpaper_map( "https://blogger.googleusercontent.com/img/a/AVvXsEj6xCwTs7GmUN1YVXfQxF9_mxchjeFqKeMwDkHRf1W9ViMKTH8SHD7i63JeqNoY2lyJafbUzyTA_cDsSljH7WKjTyVfCQ2q6NM4RLZcb1Vwh71SuMZS4q4lTrhVBhuZVTicuAuYVzrGZ1yXI2mf7p9TrgHr4baHNOO0BQaNUpRK61_PcURwcs-IXirn=s1560");
		wallpaper_map( "https://blogger.googleusercontent.com/img/a/AVvXsEjC5Q2Xb-DUXabX_fIl3K4BZ6IBkTntT3SRsBjoHvc3Xih5xOGtjDBBTdL7T5p_HRWdYoF2wMKMxJFNcWgTmzIwrk98gpmiXaLt612jB5BB_nF82GgnFAM60FRrE04arwqaE_GDTcgwXHBa2yqXKm_DpAdX9TsrkkBW3-AmBWdRNMgcLBpMdPZKQRUX=s1560");
		wallpaper_map( "https://blogger.googleusercontent.com/img/a/AVvXsEibBnrjgyYMkkFjr20x_1cNPza6iqMr3LCvgLBc6QwEjNTe8GLoOZf0kiG9FYMxRZZdGWpuL5ZoW943PcpFUlzWAAzRZ-PCGTyntN_2DTk6SP-daWVfcAPNDIML1fqtgmdJeerH3-j_PokRgu8oQ4uoPh68-TVes-QoSepKMGrJz-yTt5XlaZKt9VDR=s1560");
		wallpaper_map( "https://blogger.googleusercontent.com/img/a/AVvXsEjgd1xSPfRj4tgCXadVDvaCxclVykrya7k6Vs38C2duTEnW2STGhKQKHe6kPCjxpAW7TxrAnKAE4Fma3GxA32eZMXSODxa3Q1_398judLVj-ow5YHlL-dPzYotcn3uvZdtd3wYpIT6ZjCWarjFbebyEUGB4n34gJ45l6UjnyWFT-GdcrZETgeuvyDWF=s1560");
		wallpaper_map( "https://blogger.googleusercontent.com/img/a/AVvXsEglEVALuMkC37jpCcxMjzfvKPApQ4iUt6AjprtAXvLXpjfR1jDVkbBrnh7mnNYDWJg8qddu4guLrD3fH8g7ZFmLd3_utiJnPAHDuQh2qkY20kODN_v8MKaQZ2S298SzZJAUPe5mr1S_1iiekTdmLPtz7ySykSfI9ppl19Oj7s9LBFEdD6e8lgL1wzFz=s1560");
		wallpaper_map( "https://blogger.googleusercontent.com/img/a/AVvXsEi5jyk7BFNhJctop3RTfX-hrRdpvq45qm285VwWIIa1Ruo0lY8og7MYg-a_t81XcUQPVnMDOJGcdnKZi0WG2GXTrNtOQVMEKIWvmgmTI4S_WjsFiFJX7-k7GtxsSYHeDkRKyK9api6LX8kP5paZ79fWY3-1Ub1AOXrk6UzV8Iyz9BGPGro55XZk5exk=s1560");
		wallpaper_map( "https://blogger.googleusercontent.com/img/a/AVvXsEhCCF9DFZ4Ozilad9J-ntA1PQYkLr8v6r995dV5FuRMWHCvgcRPVTc9NbOPyXNf-uJiJfPK0D4KDvRBqaNEK0LjOIIdhaZjFlHpY1iX5k3fpkP_Q8BAy6hvwM7EiRp5OOClWxuXkgGwKudUQnKdbO0jOV026EJxRjVqV5yPtOw5L37lCaTuujC79PZj=s1560");
		wallpaper_map( "https://blogger.googleusercontent.com/img/a/AVvXsEiafghfvFfK2ALNZ6fSq988KdP7xX08ADytdpDoAQilkXuAPPsZZIh11UPG3e7Lo-9jWIrTDeZGGpBTdZXn87ZVKcSK6pyc-OoQepYNY3WNTpXCKiZGZrHfypJcIiTf4fwRCNV36rauiBmMJBL8L6WdXJ47Am9fUl0wC5-ZZGCONgDQ_pVKbMdMD4K4=s1560");
		wallpaper_map( "https://blogger.googleusercontent.com/img/a/AVvXsEgh6HLiSTUc5GG5RIR121bs2knj3qlVKJiYzE5LtIgdIcStdQngg8m5LayHMk2tJhvGkbQpOEzZrnhRin1dVXtTm_5dDDNSH2AYwqSTrwWN3dgNMiNRwgssyHSF4ieNr5gygeXZAqkSuBbMbulHu1MD8h2RK73FWWEYoS-YDBIHkABUHrjJk2hmctm1=s1560");
		wallpaper_map( "https://blogger.googleusercontent.com/img/a/AVvXsEigxOyNa2rhjNum8ds6xpgeEscZ4TYoTd47TEL1FOQy895L5hY5O_DyPNm7-uJEyCqoV3qEAo6Eon9jDcQz6mhhj9laUSj_1etEax3kG8ozgXFN8JsaJInFVhQGBoi1nLXkG6Adn4Gg8FKQDEuKEBFCN57CAD9PTHuxQMvp7yNs8VDBee0fyAe4SF1I=s1560");
		wallpaper_map( "https://blogger.googleusercontent.com/img/a/AVvXsEgBqjIyTb8XEGgXwDvBVySTvGWAiJ6ZUbM5qK3RGvtr5Z8Kfxd3GjRFKCJ1RK3w6pKSHjNf88e2Z4aVqAMF4ejMSF9jWdY6kcAgnimHyewyuNt4LvwV5CRtNt7UTT1uz-H4pNC1qStcyNNw814c33npqA2KgrQPiZKsmZQS294nMOjwq_sk0rqVx1Pu=s1560");
		wallpaper_map( "https://blogger.googleusercontent.com/img/a/AVvXsEg_N0fz69xdPe0zQiDrvnRPePYbS-UM0Jonk1zcLUI0etCCY_5GMNyBAyv-6JUnTF2HAdR5ZJYqLFVcJAiDNnfnEib8QJIAfTW3r9CccFWxrO5VF3Rq1TXlIPeYqWNJsq1w2pW77hpzodPX_HrcpI0dhDXr_8O00QSTl_z-w46xrYPTJzEEML2r7E5Y=s2152");
		wallpaper_map( "https://blogger.googleusercontent.com/img/a/AVvXsEgWhfOEINoYWWOJY86YB-XjKt2ulyBqx9FQ5Rvhtp6nHg-S9mkLAB7wPlTbWExpGdA3cNd5DUJWx3Eln8I5WcFSKjuf4A7p_pu6h6dlK4bvsYm7xmpXACtoPVecpjv71pTtfEhVYkzcyQjWMSoz_nEzy7KW4Sl7BDLkX0sNQQUE8lWhPsmkCX5lyRUu=s2152");
		wallpaper_map( "https://blogger.googleusercontent.com/img/a/AVvXsEh8esPGm4m5UjDcWvddwX1Z2WWF6MHifu0ID-s8Qk7JrMhroraxTS1i4fCi9mvWc6gN68PoDKpoqTdcgd9VfoJngedWaeHUf-Lj047l6yIu-J_D66G0tFlVyUSRw2qvmzsmdLbl7zWCdlKxSi_38RRsxmirtY3wpU-rfoi6Q_oagZUwI4AL8YwUNpF3=s2152");
		wallpaper_map( "https://wallpaperaccess.com/full/1075840.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/858443.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/743302.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/825620.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/858458.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/1075855.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/2061727.png");
		wallpaper_map( "https://wallpaperaccess.com/full/2061731.png");
		wallpaper_map( "https://wallpaperaccess.com/full/2061733.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/2061738.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/2061740.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/2061743.png");
		wallpaper_map( "https://wallpaperaccess.com/full/2061755.png");
		wallpaper_map( "https://wallpaperaccess.com/thumb/4736034.png");
		wallpaper_map( "https://wallpaperaccess.com/full/1255096.png");
		wallpaper_map( "https://wallpaperaccess.com/full/1426612.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/1298460.png");
		wallpaper_map( "https://wallpaperaccess.com/full/2914120.png");
		wallpaper_map( "https://wallpaperaccess.com/full/2328800.png");
		wallpaper_map( "https://wallpaperaccess.com/full/1345626.png");
		wallpaper_map( "https://wallpaperaccess.com/full/1345566.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/3155424.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/2440118.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/268644.png");
		wallpaper_map( "https://wallpaperaccess.com/full/783664.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/820340.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/820342.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/783685.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/820348.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/820334.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/1255364.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/1255370.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/1255453.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/1254983.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/1255560.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/2144078.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/2144088.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/2144089.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/818899.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/404641.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/2144101.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/2144130.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/2144135.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/2144137.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/1255298.png");
		wallpaper_map( "https://wallpaperaccess.com/full/2164921.png");
		wallpaper_map( "https://wallpaperaccess.com/full/1500819.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/2164938.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/1500869.png");
		wallpaper_map( "https://wallpaperaccess.com/full/1500857.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/2165045.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/797902.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/1985589.png");
		wallpaper_map( "https://wallpaperaccess.com/full/1985599.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/1985635.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/1345588.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/2512378.png");
		wallpaper_map( "https://wallpaperaccess.com/full/1980712.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/858416.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/820341.png");
		wallpaper_map( "https://wallpaperaccess.com/full/338666.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/1255422.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/1985588.png");
		wallpaper_map( "https://wallpaperaccess.com/full/1255690.png");
		wallpaper_map( "https://wallpaperaccess.com/full/1255437.png");
		wallpaper_map( "https://wallpaperaccess.com/full/1255489.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/802963.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/1345560.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/1445962.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/1500871.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/2914182.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/1255090.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/1255145.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/1255160.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/1255228.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/1941775.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/1941831.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/1255255.jpg");
		wallpaper_map( "https://wallpaperaccess.com/full/783664.jpg");
		wallpaper_map( "https://play-lh.googleusercontent.com/o_e4PbokA9Di-8M9OE1eu0FCtzkBLt7zciABa5RxawK_bVSW0Macms4rpeVoEXiXhg=h750");
		wallpaper_map( "https://www.teahub.io/photos/full/280-2807301_29-299418-download-wallpaper-samsung-galaxy-j7-prime..jpg");
		wallpaper_map( "https://mcdn.wallpapersafari.com/medium/70/95/04Rjt2.png");
		wallpaper_map( "https://wallpaperaccess.com/full/526602.jpg");

	}





}

package subhamjit.samsungwallz;

import android.content.*;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;

import android.app.*;
import android.net.*;
import android.view.View;
import android.widget.Toast;

public class Util {


    public static boolean isConnected(Context a) {
        ConnectivityManager connectivityManager = (ConnectivityManager)
                a.getSystemService(Activity.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }


    public static int getRandomNo(int _min, int _max) {
        Random random = new Random();
        return random.nextInt(_max - _min + 1) + _min;
    }

    public static String High_ImgQuality() {

        return "q=100&w=1000";
    }

    public static String Low_ImgQuality() {

        return "q=80&w=400";
    }


    public static void showAnimationName(final View view, final String AnimationName) {
        view.setTransitionName(AnimationName);
    }

    public static void setActivityAnimation(final View view, final String AnimationName, Activity ctx, final Intent _intent) {
        view.setTransitionName(AnimationName);
        ActivityOptions optionsCompat = ActivityOptions.makeSceneTransitionAnimation(ctx,
                view, AnimationName);
        ctx.startActivity(_intent, optionsCompat.toBundle());
    }


    public static void showAlert(String msg, boolean is_cancel, String title, Activity ctx) {
        try {
            new AlertDialog.Builder(ctx)
                    .setMessage(msg.trim())
                    .setCancelable(is_cancel)
                    .setTitle(title.trim())
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            ctx.finish();
                        }
                    }).create().show();
        } catch (Exception e) {


        }

    }


    public static String copyFromInputStream(InputStream inputStream) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        byte buf[] = new byte[1024];
        int i;
        try {
            while ((i = inputStream.read(buf)) != -1) {
                outputStream.write(buf, 0, i);
            }
            outputStream.close();
            inputStream.close();
        } catch (IOException e) {

        }
        return outputStream.toString();
    }

    public static void showToast(String _msg, Context ctx) {

        try {
            Toast.makeText(ctx, _msg, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
        }


    }

    public static void show_no_connection(Activity ctx) {

        if (Util.isConnected(ctx)) {

            Util.showAlert("Retry task again.",
                    false, "Internet slow! Try again", ctx);


        } else {

            Util.showAlert("Check your WIFI or Mobile Internet connection..",
                    false, "No internet!", ctx);

        }
    }


}
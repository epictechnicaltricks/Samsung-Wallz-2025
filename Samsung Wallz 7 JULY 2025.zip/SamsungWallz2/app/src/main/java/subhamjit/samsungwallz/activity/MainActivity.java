package subhamjit.samsungwallz.activity;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.play.core.appupdate.AppUpdateInfo;
import com.google.android.play.core.appupdate.AppUpdateManager;
import com.google.android.play.core.appupdate.AppUpdateManagerFactory;
import com.google.android.play.core.install.model.AppUpdateType;
import com.google.android.play.core.install.model.UpdateAvailability;

import eightbitlab.com.blurview.BlurView;
import eightbitlab.com.blurview.RenderScriptBlur;
import subhamjit.samsungwallz.R;
import subhamjit.samsungwallz.Util;
import subhamjit.samsungwallz.frags.Fragment_fav;
import subhamjit.samsungwallz.frags.Fragment_home;
import subhamjit.samsungwallz.frags.Fragment_wallz_store;


public class MainActivity extends  AppCompatActivity  { 
	
	
//	private ViewPager viewpager1;
	private BottomNavigationView bottomnavigation1;
	BlurView blurView;



	Fragment_home fragment1 = new Fragment_home();
	Fragment_wallz_store fragment2 = new Fragment_wallz_store();
	Fragment_fav fragment3 = new Fragment_fav();
	Fragment active = fragment1;
	final FragmentManager fm = getSupportFragmentManager();

//	private AdView mAdView;

	// Creates instance of the manager.
	private AppUpdateManager appUpdateManager;
	private static int UPDATE_CODE=2342;

	private void checkUpdate() {
		Log.d("update1231", "checkUpdate");
		Task<AppUpdateInfo> appUpdateInfoTask = appUpdateManager != null ? appUpdateManager.getAppUpdateInfo() : null;
		if (appUpdateInfoTask != null) {
			appUpdateInfoTask.addOnSuccessListener(new OnSuccessListener<AppUpdateInfo>() {
				@Override
				public void onSuccess(AppUpdateInfo appUpdateInfo) {
					if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE
							&& appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.FLEXIBLE)) {
						// Request the update.
						try {
							appUpdateManager.startUpdateFlowForResult(
									// Pass the intent that is returned by 'getAppUpdateInfo()'.
									appUpdateInfo,
									// Or 'AppUpdateType.FLEXIBLE' for flexible updates.
									AppUpdateType.IMMEDIATE,
									// The current activity making the update request.
									MainActivity.this,
									// Include a request code to later monitor this update request.
									UPDATE_CODE);
						} catch (IntentSender.SendIntentException e) {
							e.printStackTrace();
						}
						Log.d("update1231", "Update available");
					} else {
						Log.d("update1231", "No Update available");
					}
				}
			});

		}
	}






	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);


		///////////////////////////

		appUpdateManager = AppUpdateManagerFactory.create(this);

		checkUpdate();


		//mAdView = findViewById(R.id.adView);






		fm.beginTransaction().add(R.id.frame_layout, fragment3, "3").hide(fragment3).commit();
		fm.beginTransaction().add(R.id.frame_layout, fragment2, "2").hide(fragment2).commit();
		fm.beginTransaction().add(R.id.frame_layout,fragment1, "1").commit();


		initialize();
		initializeLogic();
	}

	@Override
	protected void onResume() {


		super.onResume();
	}

	@Override
	public void onBackPressed() {


        SharedPreferences sharedPreferences2 = getSharedPreferences("MySharedPref2", MODE_PRIVATE);
		/*final SharedPreferences.Editor myEdit = sharedPreferences2.edit();
		myEdit.putString("rate","true");
		myEdit.apply();*/
if(!sharedPreferences2.getString("rate","").equals("true"))
{
	cus_rate("https://play.google.com/store/apps/details?id="+getPackageName());
}else {

	finishAffinity();
	super.onBackPressed();
}

	}


	private void cus_rate(String open_link) {
		try {
			final androidx.appcompat.app.AlertDialog dialog3 = new androidx.appcompat.app.AlertDialog.Builder(getApplicationContext()).create();
			View inflate = getLayoutInflater().inflate(R.layout.rating,null);

			dialog3.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
			dialog3.setView(inflate);


			final TextView rate = inflate.findViewById(R.id.rate);
			final TextView later = inflate.findViewById(R.id.later);


			BlurView blurView = inflate.findViewById(R.id.blurView);
			float radius = 14f;
			View decorView = getWindow().getDecorView();
			ViewGroup rootView = decorView.findViewById(android.R.id.content);
			Drawable windowBackground = decorView.getBackground();
			blurView.setupWith(rootView, new RenderScriptBlur(MainActivity.this)) // or RenderEffectBlur
					.setFrameClearDrawable(windowBackground) // Optional
					.setBlurRadius(radius);




			dialog3.setCancelable(true);



			later.setOnClickListener(view -> {

           /* Intent in = new Intent();
            in.setClass(getApplicationContext(),ShowWallz.class);
            // in.putExtra("rate","true");
            startActivity(in);*/
				finish();
			});


			rate.setOnClickListener(_view -> {
				if(!open_link.equals("")){

					Util.showToast("Thank you ♥", MainActivity.this);

					//it will rest the drop date after user click the

					// rate us button
					SharedPreferences sharedPreferences2 = getSharedPreferences("MySharedPref2", MODE_PRIVATE);
					final SharedPreferences.Editor myEdit = sharedPreferences2.edit();
					myEdit.putString("rate","true");
					myEdit.apply();


					Intent in = new Intent();
					in.setAction(Intent.ACTION_VIEW);
					in.setData(Uri.parse(open_link));
					startActivity(in);
					finish();



					dialog3.dismiss();
				}

			});
			dialog3.show();
		}catch (Exception e)
		{
finish();
		}

	}

	private void initialize() {


		SharedPreferences sharedPreferences2 = getSharedPreferences("MySharedPref2", MODE_PRIVATE);
		if(sharedPreferences2.getString("premium","").equals("false")) {

			//loadBannerAd(mAdView);
			Log.d("AD2123","HOME AD SHOWING");

		}else {
			Log.d("AD2123","HOME AD NOT SHOWING");
		}



		//viewpager1 = findViewById(R.id.viewpager1);
		bottomnavigation1 = findViewById(R.id.bottomnavigation1);



		blurView = findViewById(R.id.blurView);
		float radius = 16f;

		View decorView = getWindow().getDecorView();
		ViewGroup rootView = (ViewGroup) decorView.findViewById(android.R.id.content);

		Drawable windowBackground = decorView.getBackground();

		blurView.setupWith(rootView, new RenderScriptBlur(this)) // or RenderEffectBlur
				.setFrameClearDrawable(windowBackground) // Optional
				.setBlurRadius(radius);


		Window w = getWindow(); // in Activity's onCreate() for instance
		w.setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
				WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);


	/*	Fragment_home fragment = new Fragment_home();
		FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
		fragmentTransaction.replace(R.id.frame_layout, fragment, "");
		fragmentTransaction.commit();
*/

		fm.beginTransaction().hide(active).show(fragment1).commit();
		active = fragment1;


		bottomnavigation1.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
			@Override
			public boolean onNavigationItemSelected(@NonNull MenuItem item) {
				//viewpager1.setCurrentItem((int)_itemId);
				bottomnavigation1.getMenu().getItem(item.getItemId()).setChecked(true);
				switch (item.getItemId())
				{
					case 0 :


						fm.beginTransaction().hide(active).show(fragment1).commit();
						active = fragment1;


						/*FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
						fragmentTransaction.replace(R.id.frame_layout, fragment, "");

						fragmentTransaction.commit();*/

						break;

					case 1 :

						fm.beginTransaction().hide(active).show(fragment2).commit();
						active = fragment2;
/*
						FragmentTransaction fragmentTransaction1 = getSupportFragmentManager().beginTransaction();
						fragmentTransaction1.replace(R.id.frame_layout, fragment1, "");

						fragmentTransaction1.commit();*/

						break;

					case 2 :

						fm.beginTransaction().hide(active).show(fragment3).commit();
						active = fragment3;

						/*FragmentTransaction fragmentTransaction2 = getSupportFragmentManager().beginTransaction();
						fragmentTransaction2.replace(R.id.frame_layout, fragment2, "");

						fragmentTransaction2.commit();*/

						break;
				}

				return false;
			}
		});
	}
	
	private void initializeLogic() {


		bottomnavigation1.getMenu().add(0, 0, 0, "Home").setIcon(R.drawable.ic_home_grey);
		bottomnavigation1.getMenu().add(0, 1, 0, "Wallz Store").setIcon(R.drawable.ic_filter_hdr_grey);
		bottomnavigation1.getMenu().add(0, 2, 0, "Favs").setIcon(R.drawable.anim_settings);
		bottomnavigation1.getMenu().getItem(0).setChecked(true);
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent _data) {
		if (requestCode == UPDATE_CODE) {
			if (resultCode == Activity.RESULT_CANCELED) {



				Log.d("update1231", "Update flow failed! Result code: " + resultCode);
			}else {
				appUpdateManager.completeUpdate();

				Log.d("update1231", "Update SUCCESS Result code: " + resultCode);
			}


		}
		super.onActivityResult(requestCode, resultCode, _data);

	}
	

	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}






}

package subhamjit.samsungwallz.activity;


import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.WallpaperManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import eightbitlab.com.blurview.BlurView;
import eightbitlab.com.blurview.RenderScriptBlur;
import subhamjit.samsungwallz.FileUtil;
import subhamjit.samsungwallz.ProgressDialogUtility;
import subhamjit.samsungwallz.R;
import subhamjit.samsungwallz.Util;

public class ShowWallz extends AppCompatActivity {

    ImageView wallz_img;
    LinearLayout wallz_progress;

    LinearLayout rl,bg;

    final String[] listItems = new String[]{"Home Screen", "Lock Screen", "Both Home and Lock"};

    final int[] checkedItem = {0};

    String isSelected="";

    WallpaperManager wallpaperManager;

    Handler h;

 //   LottieAnimationView animationView;

    private InterstitialAd mInterstitialAd;

    ProgressDialogUtility progressDialogUtility;

  //  private AdView mAdView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.show_wallz);



       // mAdView = findViewById(R.id.adView);

        h = new Handler();
        wallz_img = findViewById(R.id.wall_img);
       // animationView = findViewById(R.id.animationView);
       // animationView.setVisibility(View.VISIBLE);
       // animationView.pauseAnimation();


        wallz_progress = findViewById(R.id.wallz_progress);
        rl = findViewById(R.id.wallz_img_layout);

        bg = findViewById(R.id.bg);

        wallpaperManager = WallpaperManager.getInstance(this);


        Util.showAnimationName(rl, "shubham");


        Window w = getWindow(); // in Activity's onCreate() for instance
        w.setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);



        init();





    }

    void init()
    {

         progressDialogUtility = new ProgressDialogUtility(this);


        SharedPreferences sharedPreferences2 = getSharedPreferences("MySharedPref2", MODE_PRIVATE);
        if(sharedPreferences2.getString("premium_show_first","").equals("")) {
            final SharedPreferences.Editor myEdit = sharedPreferences2.edit();
            myEdit.putString("premium_show_first", "true");
            myEdit.apply();
        }




        wallz_progress.setVisibility(View.VISIBLE);
        bg.setVisibility(View.GONE);


        Log.d("url111", getIntent().getStringExtra("wallz_url"));

        String url = getIntent().getStringExtra("wallz_url");
        String final_url;
        if(Util.isConnected(ShowWallz.this)) {
            final_url = url.replace("q=80&w=400",Util.High_ImgQuality());

        } else {
            final_url = url;
            Toast.makeText(this, "No internet!", Toast.LENGTH_SHORT).show();
        }

        final Animation slide_up = AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.fade_in);

        final Animation zoom_out = AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.zoom_oit);


        Glide.with(getApplicationContext()).load(
                        Uri.parse(final_url))
                .error(R.drawable.no_internet)

                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object o, Target<Drawable> target, boolean b) {

                     //  Toast.makeText(ShowWallz.this, "", Toast.LENGTH_SHORT).show();
                        wallz_img.setImageDrawable(getResources().getDrawable(R.drawable.no_internet));

                        wallz_progress.setVisibility(View.GONE);
                        bg.setVisibility(View.VISIBLE);
                     //   wallz_img.startAnimation(zoom_out);
                   //     bg.startAnimation(slide_up);

                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable drawable, Object o, Target<Drawable> target, DataSource dataSource, boolean b) {
                        wallz_progress.setVisibility(View.GONE);
                       // Toast.makeText(ShowWallz.this, "loaded", Toast.LENGTH_SHORT).show();


                        wallz_img.startAnimation(zoom_out);
                        bg.setVisibility(View.VISIBLE);
                       bg.startAnimation(slide_up);

                        wallz_img.setImageDrawable(drawable);
                        return false;
                    }
                })
                .placeholder(R.drawable.hold_tight)
                .thumbnail(0.01f)
                .into(wallz_img);

        Block_Screenshot();

    }

    @Override
    protected void onResume() {

        super.onResume();
    }


    private void loadAndShowInterstitialAd(boolean isFromSetWallz) {


        SharedPreferences sharedPreferences2 = getSharedPreferences("MySharedPref2", MODE_PRIVATE);
        if(sharedPreferences2.getString("premium","").equals("false")) {


            progressDialogUtility.show();

            AdRequest adRequest = new AdRequest.Builder().build();

            InterstitialAd.load(this,"ca-app-pub-7162704238713975/1007354167" , adRequest, // Replace with your Ad Unit ID
                    new InterstitialAdLoadCallback() {
                        @Override
                        public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                            progressDialogUtility.hide();
                            mInterstitialAd = interstitialAd;
                            // Toast.makeText(ShowWallz.this, "Ad Loaded", Toast.LENGTH_SHORT).show();

                            // Automatically show the ad after it's loaded
                            showInterstitialAd(isFromSetWallz);



                        }

                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                            mInterstitialAd = null;

                            progressDialogUtility.hide();
                            if(isFromSetWallz)
                            {
                                show_wallpaperset();
                            }
                            //Toast.makeText(MainActivity.this, "Ad Failed to Load", Toast.LENGTH_SHORT).show();
                        }
                    });

            Log.d("AD2123","SHOWWALZ AD SHOWING");
        }else {
            if(isFromSetWallz)
            {
                show_wallpaperset();
            }
            Log.d("AD2123","NO AD SHOWING");
        }

    }


    private void showInterstitialAd(boolean isFromSetWallz) {
        if (mInterstitialAd != null) {
            mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override
                public void onAdDismissedFullScreenContent() {
                    // Load a new ad after the current one is dismissed
                    mInterstitialAd = null;
                    if(isFromSetWallz)
                    {
                        show_wallpaperset();
                    }

                   // loadAndShowInterstitialAd();
                }

                @Override
                public void onAdFailedToShowFullScreenContent(AdError adError) {
                    mInterstitialAd = null;
                    if(isFromSetWallz)
                    {
                        show_wallpaperset();
                    }

                }
            });

            mInterstitialAd.show(this);
        } else {
            if(isFromSetWallz)
            {
                show_wallpaperset();
            }
           // Toast.makeText(this, "Ad not ready to show", Toast.LENGTH_SHORT).show();
        }
    }

    public void set_Wallz(View view)
    {
        loadAndShowInterstitialAd(true);
    }

    public void download_Wallz(View view)
    {

        loadAndShowInterstitialAd(false);

        Toast.makeText(this, "SUCCESS", Toast.LENGTH_SHORT).show();
        if(Build.VERSION.SDK_INT >= 33)
        {

            long time= System.currentTimeMillis();
            String path_location = FileUtil
                    .getPublicDir(Environment.DIRECTORY_DOWNLOADS)
                    .concat("/#"+getString(R.string.app_name)+"/");

            _save_image_to_storage(wallz_img,time+".png",path_location,100);


        } else
        {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                    && ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED ) {
              new AlertDialog.Builder(ShowWallz.this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                      .setTitle("STORAGE Permission required to download!")
                      .setPositiveButton("ALLOW", new DialogInterface.OnClickListener() {
                          @Override
                          public void onClick(DialogInterface dialogInterface, int i) {
                              ActivityCompat.requestPermissions(ShowWallz.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);

                          }
                      }).setCancelable(false).setNegativeButton("OPEN SETTINGS", new DialogInterface.OnClickListener() {
                          @Override
                          public void onClick(DialogInterface dialogInterface, int i) {
                              Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                              Uri uri = Uri.fromParts("package", getPackageName(), null);
                              intent.setData(uri);
                              startActivity(intent);
                          }
                      }).create().show();
                   }  else
                   {
                       long time= System.currentTimeMillis();
                       String path_location = FileUtil
                               .getPublicDir(Environment.DIRECTORY_DOWNLOADS)
                               .concat("/#"+getString(R.string.app_name)+"/");

                       _save_image_to_storage(wallz_img,time+".png",path_location,100);


                   }

        }





    }


    public void share_Wallz(View view)
    {
        Toast.makeText(this, "Thank you ♥ for sharing..", Toast.LENGTH_SHORT).show();
        BitmapDrawable bitmapDrawable = (BitmapDrawable) wallz_img.getDrawable();
        Bitmap bitmap = bitmapDrawable.getBitmap();
        loadAndShowInterstitialAd(false);
        share_Image_with_Text(bitmap);
    }






    private void cus_rate(String open_link, Boolean isRate)
    {
        final androidx.appcompat.app.AlertDialog dialog3 = new androidx.appcompat.app.AlertDialog.Builder(this).create();
        View inflate = getLayoutInflater().inflate(R.layout.success,null);

        dialog3.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dialog3.setView(inflate);


        final TextView rate = inflate.findViewById(R.id.rate);
        final TextView later = inflate.findViewById(R.id.later);
        final RatingBar ratingbar1 =  inflate.findViewById(R.id.ratingbar1);



        if(isRate) {
            ratingbar1.setVisibility(View.VISIBLE);
            rate.setVisibility(View.VISIBLE);
        } else {
            rate.setVisibility(View.GONE);
            ratingbar1.setVisibility(View.GONE);
        }



        BlurView blurView = inflate.findViewById(R.id.blurView);
        float radius = 14f;
        View decorView = getWindow().getDecorView();
        ViewGroup rootView = (ViewGroup) decorView.findViewById(android.R.id.content);
        Drawable windowBackground = decorView.getBackground();
        blurView.setupWith(rootView, new RenderScriptBlur(ShowWallz.this)) // or RenderEffectBlur
                .setFrameClearDrawable(windowBackground) // Optional
                .setBlurRadius(radius);



        dialog3.setCancelable(true);



        later.setOnClickListener(view -> {
            dialog3.dismiss();
           /* Intent in = new Intent();
            in.setClass(getApplicationContext(),ShowWallz.class);
            // in.putExtra("rate","true");
            startActivity(in);*/
            //finish();
        });


        rate.setOnClickListener(_view -> {
            if(!open_link.equals("")){

                Util.showToast("Thank you ♥", ShowWallz.this);
                //it will rest the drop date after user click the

                // rate us button

                SharedPreferences sharedPreferences2 = getSharedPreferences("MySharedPref2", MODE_PRIVATE);
                final SharedPreferences.Editor myEdit = sharedPreferences2.edit();
                myEdit.putString("rate","true");
                myEdit.apply();


                Intent in = new Intent();
                in.setAction(Intent.ACTION_VIEW);
                in.setData(Uri.parse(open_link));
                startActivity(in);
                finish();


                dialog3.dismiss();
            }

        });
        dialog3.show();
    }

    private void cus_rate_failure()
    {
        final androidx.appcompat.app.AlertDialog dialog3 = new androidx.appcompat.app.AlertDialog.Builder(this).create();
        View inflate = getLayoutInflater().inflate(R.layout.failure,null);

        dialog3.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dialog3.setView(inflate);


        final TextView rate = (TextView) inflate.findViewById(R.id.rate);
        final TextView later = (TextView) inflate.findViewById(R.id.later);





        dialog3.setCancelable(false);



        later.setOnClickListener(view -> {


            finish();
        });


        rate.setOnClickListener(_view -> {
            dialog3.dismiss();

        });
        dialog3.show();
    }






    public void review_Wallz(View view)
    {
        Toast.makeText(this, "ssdadsaddssadsa234243", Toast.LENGTH_SHORT).show();
    }

    void Block_Screenshot () {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
    }

    private void share_Image_with_Text(Bitmap bitmap) {
        Uri uri = get_path_image_for_Share(bitmap);

        Intent intent = new Intent(Intent.ACTION_SEND);

        intent.putExtra(Intent.EXTRA_STREAM, uri);
        intent.putExtra(Intent.EXTRA_TEXT, "More Wallpapers \n https://play.google.com/store/apps/details?id="+getPackageName());
        intent.putExtra(Intent.EXTRA_SUBJECT, "Share Wallpaper");
        intent.setType("image/png");
        startActivity(Intent.createChooser(intent, "Share on"));
    }


    // Retrieving the url to share
    private Uri get_path_image_for_Share(Bitmap bitmap)
    {
        File imagefolder = new File(getCacheDir(), "images");
        Uri uri = null;
        try {
            imagefolder.mkdirs();
            File file = new File(imagefolder, "Wallpaper.png");
            FileOutputStream outputStream = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
            outputStream.flush();
            outputStream.close();
            uri = FileProvider.getUriForFile(this, "subhamjit.samsungwallz.fileprovider", file);
        } catch (Exception e) {
            Toast.makeText(this, "" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
        return uri;
    }

    void show_wallpaperset()
    {





        // instance of alert dialog to build alert dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(ShowWallz.this, AlertDialog.THEME_DEVICE_DEFAULT_DARK);
        //builder.setIcon(R.drawable.wallpaper);



        builder.setTitle("Set as");
        builder.setSingleChoiceItems(listItems, checkedItem[0], (dialog, which) -> {



            checkedItem[0] = which;
            isSelected = listItems[which];




        });


        builder.setPositiveButton("SET", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {





                if(isSelected.equals(""))
                {
                    isSelected = "Home Screen";
                }

                dialog.cancel();

                wallz_progress.setVisibility(View.VISIBLE);

                setWall();




            }
        });

        // set the negative button to do some actions
        builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        builder.create().show();

        // show the alert dialog

    }
    void setWall() {
        // Extract bitmap from the image view
        Bitmap bitmap = ((BitmapDrawable) wallz_img.getDrawable()).getBitmap();

        // Use AsyncTask to perform the wallpaper setting task in the background
        new AsyncTask<Bitmap, Void, Boolean>() {
            @SuppressLint("StaticFieldLeak")
            @Override
            protected Boolean doInBackground(Bitmap... bitmaps) {
                // This is the background thread where wallpaper setting happens
                try {
                    switch (isSelected) {
                        case "Home Screen":
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                                wallpaperManager.setBitmap(bitmaps[0], null, true, WallpaperManager.FLAG_SYSTEM);
                                return true; // success
                            }
                            break;

                        case "Lock Screen":
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                                wallpaperManager.setBitmap(bitmaps[0], null, true, WallpaperManager.FLAG_LOCK);
                                return true; // success
                            }
                            break;

                        case "Both Home and Lock":
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                                wallpaperManager.setBitmap(bitmaps[0], null, true, WallpaperManager.FLAG_LOCK);
                            }
                            Bitmap bitmap2 = ((BitmapDrawable) wallz_img.getDrawable()).getBitmap();
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                                wallpaperManager.setBitmap(bitmap2, null, true, WallpaperManager.FLAG_SYSTEM);
                                return true; // success
                            }
                            break;
                    }
                } catch (IOException | RuntimeException e) {
                    e.printStackTrace();
                }
                return false; // failure
            }

            @Override
            protected void onPostExecute(Boolean result) {
                // This method runs on the main thread after doInBackground completes
                if (result) {
                    // Success callback
                    runOnUiThread(() -> success());
                } else {
                    // Failure callback
                    runOnUiThread(() -> {
                        cus_rate_failure();
                        Toast.makeText(ShowWallz.this, "Failed to set wallpaper", Toast.LENGTH_SHORT).show();
                    });
                }
            }
        }.execute(bitmap); // Execute the AsyncTask with the bitmap
    }


    void success()
    {

      //  animationView.playAnimation();
        wallz_progress.setVisibility(View.GONE);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                SharedPreferences sharedPreferences2 = getSharedPreferences("MySharedPref2", MODE_PRIVATE);
                if(!sharedPreferences2.getString("rate","").equals("true")) {
                    cus_rate("https://play.google.com/store/apps/details?id="+getPackageName(),true);
                }else {
                    cus_rate("https://play.google.com/store/apps/details?id="+getPackageName(),false);
                }
            }
        }, 3000);









        //Toast.makeText(ShowWallz.this, "Congratulations", Toast.LENGTH_SHORT).show();

    }

    public void _save_image_to_storage (final ImageView _view, final String _name,  final String _save_path, final double _quality)
    {

        try{
            BitmapDrawable _imageviewBD = (BitmapDrawable) _view.getDrawable();
            Bitmap _imageviewB = _imageviewBD.getBitmap();
            FileOutputStream _imageviewFOS = null;
            File _imageviewF = Environment.getExternalStorageDirectory();
            File _imageviewF2 = new File(_save_path);
            _imageviewF2.mkdirs();
            File _imageviewF3 = new File(_imageviewF2, _name);
            _imageviewFOS = new FileOutputStream(_imageviewF3);
            _imageviewB.compress(Bitmap.CompressFormat.PNG, (int) _quality, _imageviewFOS);
            _imageviewFOS.flush();
            _imageviewFOS.close();
            Intent _imageviewI = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
            _imageviewI.setData(Uri.fromFile(_imageviewF)); sendBroadcast(_imageviewI);
        }catch(Exception e){
        }
        try {
            android.media.MediaScannerConnection.scanFile(ShowWallz.this,new String[]{new File(_save_path + _name).getPath()}, new String[]{"image/jpeg"}, null);
        } catch(Exception e) {}
        try {
            android.media.MediaScannerConnection.scanFile(ShowWallz.this,new String[]{new File(_save_path + _name).getPath()}, new String[]{"image/png"}, null);
        } catch (Exception e) {}


        Toast.makeText(this, "Path: Download/#"+getResources().getString(R.string.app_name)+"/", Toast.LENGTH_LONG).show();

    }


    void loadBannerAd(AdView adView){



        AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

        adView.setAdListener(new AdListener() {
            @Override
            public void onAdClicked() {
                // Code to be executed when the user clicks on an ad.
            }

            @Override
            public void onAdClosed() {
                // Code to be executed when the user is about to return
                // to the app after tapping on an ad.
            }

            @Override
            public void onAdFailedToLoad(LoadAdError adError) {
                adView.setVisibility(View.GONE);
                // Code to be executed when an ad request fails.
            }

            @Override
            public void onAdImpression() {
                // Code to be executed when an impression is recorded
                // for an ad.
            }

            @Override
            public void onAdLoaded() {
                // Code to be executed when an ad finishes loading.
            }

            @Override
            public void onAdOpened() {
                // Code to be executed when an ad opens an overlay that
                // covers the screen.
            }
        });

    }
}